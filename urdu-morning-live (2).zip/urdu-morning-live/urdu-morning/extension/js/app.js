/* صبح بخیر پیغامات — main UI */
(() => {
  "use strict";
  const { CATS, RELATIONS, byKey } = window.CATEGORIES;
  const API = (window.API_BASE || "").replace(/\/$/, "");
  const $ = id => document.getElementById(id);
  const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ---------- storage (fails soft in private mode) ----------
  const store = {
    get(k, d) { try { const v = localStorage.getItem("um." + k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } },
    set(k, v) { try { localStorage.setItem("um." + k, JSON.stringify(v)); } catch (_) {} }
  };

  const prefs = Object.assign({
    cat: "اسلامی", name: "", relation: "", gender: "", register: "", length: "medium", emoji: true,
    font: "nastaliq", size: 1.35, theme: "auto", imgTheme: "fajr", imgSize: "square", sign: ""
  }, store.get("prefs", {}));
  const qCat = new URLSearchParams(location.search).get("c"); // app shortcuts: ?c=اسلامی
  if (qCat && byKey[qCat]) prefs.cat = qCat;
  if (!byKey[prefs.cat]) prefs.cat = "اسلامی";
  const savePrefs = () => store.set("prefs", prefs);

  let history = store.get("history", []);   // [{t: text, c: category, d: timestamp}]
  let favs = store.get("favs", []);
  let current = { t: "", c: prefs.cat, src: "" };
  let undoText = null, busy = false, listTab = "hist";

  // ---------- helpers ----------
  let toastTimer;
  function toast(msg) {
    const t = $("toast"); t.firstChild.textContent = msg; t.classList.add("on");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("on"), 1800);
  }
  const plain = () => current.t.trim();

  function renderMessage(text, animate) {
    const box = $("msg"); box.textContent = "";
    let w = 0;
    for (const line of text.split("\n")) {
      const el = document.createElement("span");
      el.className = "ln";
      if (Urdu.isArabic(line)) el.classList.add("ar");
      else if (/^\(.*\)$|\((?:سورۃ|سورۂ|سنن|صحیح|درود|صحابۂ)[^)]*\)$/.test(line.trim())) el.classList.add("ref-line");
      if (animate && !REDUCED) {
        for (const part of line.split(/(\s+)/)) {
          if (!part) continue;
          if (/^\s+$/.test(part)) { el.append(part); continue; }
          const s = document.createElement("span"); s.className = "word"; s.textContent = part;
          s.style.animationDelay = Math.min(w++ * 35, 1400) + "ms"; el.append(s);
        }
      } else el.textContent = line;
      box.append(el);
    }
    const words = text.split(/\s+/).filter(Boolean).length;
    $("count").textContent = `${Urdu.toUrduDigits(words)} الفاظ`;
    updateFavBtn();
  }

  function setBadge(src) {
    const b = $("badge");
    b.hidden = !src;
    b.textContent = src === "ai" ? "✨ AI سے تازہ" : src === "edited" ? "آپ کی ترمیم" : "";
    $("refine").classList.toggle("off", !navigator.onLine);
  }

  function setBusy(on, label) {
    busy = on;
    $("card").setAttribute("aria-busy", on);
    const g = $("gen"); g.disabled = on; g.querySelector("span").textContent = on ? (label || "لکھا جا رہا ہے…") : "نیا پیغام";
    document.querySelectorAll(".refine button").forEach(b => (b.disabled = on));
  }

  function options() {
    return { category: prefs.cat, name: prefs.name, relation: prefs.relation, gender: prefs.gender,
      register: prefs.register, length: prefs.length, emoji: prefs.emoji };
  }

  async function api(body) {
    if (!navigator.onLine) throw new Error("offline");
    const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), 180000);
    try {
      const r = await fetch(API + "/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctrl.signal });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw Object.assign(new Error(j.error || "api"), { status: r.status, kind: j.kind || (r.status === 429 ? "rate_limit" : null) });
      return j;
    } finally { clearTimeout(to); }
  }

  // Same as api() but the text appears piece by piece while the model is still writing (feels much faster on a slow PC).
  async function apiStream(body, onPartial) {
    if (!navigator.onLine) throw new Error("offline");
    const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), 180000);
    try {
      const r = await fetch(API + "/api/generate/stream", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctrl.signal });
      if (r.status === 404 || (r.ok && !r.body)) return api(body); // older server without streaming
      if (!r.ok) { const j = await r.json().catch(() => ({})); throw Object.assign(new Error(j.error || "api"), { status: r.status, kind: j.kind || (r.status === 429 ? "rate_limit" : null) }); }
      const reader = r.body.getReader(), dec = new TextDecoder();
      let buf = "", text = "", final = null;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf("\n\n")) >= 0) {
          const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
          if (!chunk.startsWith("data:")) continue; // ": ping" keep-alive lines
          const ev = JSON.parse(chunk.slice(5));
          if (ev.reset) { text = ""; onPartial(""); }
          else if (ev.t) { text += ev.t; onPartial(text); }
          else if (ev.done) final = ev;
          else if (ev.error) throw Object.assign(new Error("api"), { kind: ev.kind || "failed" });
        }
      }
      if (!final) throw Object.assign(new Error("api"), { kind: "failed" });
      return { message: final.message, model: final.model, source: final.source, streamed: Boolean(text) };
    } finally { clearTimeout(to); }
  }

  function setMessage(text, src, { animate = true, remember = true } = {}) {
    current = { t: text, c: prefs.cat, src };
    stopSpeaking(); exitEdit(false);
    renderMessage(text, animate); setBadge(src);
    if (remember) {
      history = [{ t: text, c: prefs.cat, d: Date.now() }, ...history.filter(h => h.t !== text)].slice(0, 30);
      store.set("history", history); renderList();
    }
  }

  // ---------- generate & refine ----------
  async function generate() {
    if (busy) return;
    setBusy(true); undoText = null; $("undo").hidden = true;
    const avoid = history.filter(h => h.c === prefs.cat).slice(0, 3).map(h => h.t);
    try {
      const { message, streamed, source } = await apiStream({ ...options(), avoid }, t => { $("msg").textContent = t; });
      setBusy(false); showError(null); setMessage(message, source === "offline" ? "offline" : "ai", { animate: !streamed });
    } catch (e) {
      setBusy(false);
      if (current.t) renderMessage(current.t, false); else $("msg").textContent = ""; // drop the half-written text
      showError(e);
    }
  }

  // AI-only: when generation fails we explain why and offer a retry — no canned text.
  const ERR = {
    offline: "انٹرنیٹ سے رابطہ نہیں ہے۔ کنکشن چیک کر کے دوبارہ کوشش کریں۔",
    rate_limit: "AI ابھی مصروف ہے (فی منٹ کی حد پوری ہو گئی)۔ چند سیکنڈ بعد دوبارہ کوشش کریں۔",
    auth: "سرور کی API کلید درست نہیں۔ .env میں GROQ_API_KEY چیک کریں۔",
    busy: "سرور اس وقت مصروف ہے۔ تھوڑی دیر بعد کوشش کریں۔",
    ai_down: "لوکل AI (Ollama) چل نہیں رہا۔ ٹرمنل میں ollama serve چلائیں اور دوبارہ کوشش کریں۔",
    no_model: "Ollama میں کوئی ماڈل موجود نہیں۔ ٹرمنل میں ollama pull gemma4:e4b چلائیں۔",
    timeout: "AI نے جواب دینے میں بہت دیر کر دی۔ دوبارہ کوشش کریں۔",
    bad_output: "AI کا جواب درست اردو میں نہیں تھا۔ دوبارہ کوشش کریں۔",
    server: "سرور سے رابطہ نہیں ہو سکا۔ کیا سرور چل رہا ہے؟ (npm start)",
    failed: "پیغام نہیں بن سکا۔ دوبارہ کوشش کریں۔"
  };
  let errTimer;
  function showError(e) {
    const box = $("err"); clearInterval(errTimer);
    if (!e) { box.hidden = true; return; }
    const kind = e.message === "offline" ? "offline" : e.name === "AbortError" ? "timeout" : e.kind || (e.status ? "failed" : "server");
    box.querySelector("p").textContent = ERR[kind] || ERR.failed;
    box.hidden = false;
    if (!current.t) { $("msg").textContent = ""; $("count").textContent = ""; setBadge(""); }
    if (kind === "rate_limit") { // retry automatically after a short countdown
      let n = 10; const btn = box.querySelector("button");
      const tick = () => { btn.textContent = n > 0 ? `دوبارہ کوشش (${Urdu.toUrduDigits(n)})` : "دوبارہ کوشش کریں"; if (n-- <= 0) { clearInterval(errTimer); generate(); } };
      tick(); errTimer = setInterval(tick, 1000);
    } else box.querySelector("button").textContent = "دوبارہ کوشش کریں";
  }

  async function refine(action) {
    if (busy || !plain()) return;
    setBusy(true, "بہتر بنایا جا رہا ہے…");
    try {
      const { message } = await api({ ...options(), refine: { action, text: plain() } });
      undoText = { t: current.t, src: current.src };
      setBusy(false); setMessage(message, "ai");
      $("undo").hidden = false;
    } catch (e) {
      setBusy(false);
      toast(e.kind === "rate_limit" ? "AI ابھی مصروف ہے، چند سیکنڈ بعد کوشش کریں" : "بہتری نہیں ہو سکی، دوبارہ کوشش کریں");
    }
  }

  // ---------- editing ----------
  function enterEdit() {
    const ta = $("msgEdit"); ta.value = current.t; ta.hidden = false; $("msg").hidden = true;
    $("editBtn").setAttribute("aria-pressed", "true"); ta.focus();
  }
  function exitEdit(save = true) {
    const ta = $("msgEdit"); if (ta.hidden) return;
    ta.hidden = true; $("msg").hidden = false; $("editBtn").setAttribute("aria-pressed", "false");
    if (save) {
      const v = Urdu.normalize(ta.value);
      if (v && v !== current.t) { current.t = v; renderMessage(v, false); setBadge("edited"); }
    }
  }

  // ---------- share actions ----------
  async function copy() {
    exitEdit();
    try { await navigator.clipboard.writeText(plain()); toast("کاپی ہو گیا ✓"); }
    catch (_) {
      const ta = document.createElement("textarea"); ta.value = plain(); document.body.append(ta); ta.select();
      const ok = document.execCommand("copy"); ta.remove(); toast(ok ? "کاپی ہو گیا ✓" : "کاپی نہیں ہو سکا");
    }
  }
  function whatsapp() { exitEdit(); window.open("https://wa.me/?text=" + encodeURIComponent(plain()), "_blank", "noopener"); }
  async function share() {
    exitEdit();
    if (navigator.share) { try { await navigator.share({ text: plain() }); } catch (_) {} }
    else copy();
  }

  // ---------- favourites & lists ----------
  const isFav = t => favs.some(f => f.t === t);
  function updateFavBtn() {
    const on = isFav(current.t); $("fav").setAttribute("aria-pressed", on);
    $("fav").querySelector("span").textContent = on ? "محفوظ" : "پسندیدہ";
    $("favCount").textContent = favs.length ? Urdu.toUrduDigits(favs.length) : "";
  }
  function toggleFav() {
    exitEdit();
    if (!plain()) return;
    if (isFav(current.t)) { favs = favs.filter(f => f.t !== current.t); toast("پسندیدہ سے ہٹا دیا"); }
    else { favs.unshift({ t: current.t, c: current.c, d: Date.now() }); toast("پسندیدہ میں محفوظ ❤"); }
    store.set("favs", favs); updateFavBtn(); renderList();
  }
  function timeAgo(d) {
    const m = Math.round((Date.now() - d) / 60000);
    if (m < 1) return "ابھی"; if (m < 60) return `${Urdu.toUrduDigits(m)} منٹ پہلے`;
    const h = Math.round(m / 60); if (h < 24) return `${Urdu.toUrduDigits(h)} گھنٹے پہلے`;
    return `${Urdu.toUrduDigits(Math.round(h / 24))} دن پہلے`;
  }
  function renderList() {
    const box = $("listBox"), items = listTab === "hist" ? history.slice(1) : favs;
    box.textContent = "";
    if (!items.length) {
      const p = document.createElement("p"); p.className = "empty";
      p.textContent = listTab === "hist" ? "ابھی کوئی پچھلا پیغام نہیں۔" : "دل کے نشان سے پیغامات یہاں محفوظ کریں۔";
      box.append(p); updateFavBtn(); return;
    }
    for (const it of items) {
      const row = document.createElement("div"); row.className = "item";
      const b = document.createElement("button"); b.className = "text"; b.textContent = it.t.replace(/\n+/g, " · ");
      b.onclick = () => { current = { t: it.t, c: it.c, src: "" }; exitEdit(false); renderMessage(it.t, false); setBadge(""); window.scrollTo({ top: $("card").offsetTop - 80, behavior: REDUCED ? "auto" : "smooth" }); };
      const tag = document.createElement("span"); tag.className = "tag"; tag.textContent = `${(byKey[it.c] || {}).icon || ""} ${timeAgo(it.d)}`;
      const del = document.createElement("button"); del.className = "icon-btn"; del.setAttribute("aria-label", "حذف کریں");
      del.innerHTML = '<svg><use href="#i-trash"/></svg>';
      del.onclick = () => {
        if (listTab === "hist") { history = history.filter(h => h !== it); store.set("history", history); }
        else { favs = favs.filter(f => f !== it); store.set("favs", favs); }
        renderList();
      };
      row.append(b, tag, del); box.append(row);
    }
    updateFavBtn();
  }
  function setTab(t) {
    listTab = t; $("tabHist").setAttribute("aria-selected", t === "hist"); $("tabFav").setAttribute("aria-selected", t === "fav"); renderList();
  }

  // ---------- text to speech ----------
  let voice = null;
  function findVoice() { voice = (speechSynthesis.getVoices() || []).find(v => /^ur/i.test(v.lang)) || null; }
  function stopSpeaking() { if ("speechSynthesis" in window) speechSynthesis.cancel(); $("speak").setAttribute("aria-pressed", "false"); }
  function speak() {
    if (!("speechSynthesis" in window)) return toast("آپ کا براؤزر آواز کی سہولت نہیں رکھتا");
    if (speechSynthesis.speaking) return stopSpeaking();
    findVoice();
    if (!voice) return toast("اس ڈیوائس پر اردو آواز انسٹال نہیں ہے");
    const u = new SpeechSynthesisUtterance(plain().split("\n").filter(l => !Urdu.isArabic(l)).join("۔ "));
    u.voice = voice; u.lang = voice.lang; u.rate = .92;
    u.onend = u.onerror = () => $("speak").setAttribute("aria-pressed", "false");
    $("speak").setAttribute("aria-pressed", "true"); speechSynthesis.speak(u);
  }

  // ---------- image dialog ----------
  async function drawImage() {
    const d = Urdu.dateLine(new Date());
    await Card.render($("canvas"), { text: plain(), theme: prefs.imgTheme, size: prefs.imgSize, font: prefs.font, sign: prefs.sign.trim(),
      dateLine: [d.gregorian, d.hijri].filter(Boolean).join("  •  ") });
  }
  function openImage() {
    exitEdit();
    if (!plain()) return;
    const dlg = $("imgDialog");
    if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", "");
    drawImage();
  }
  function canvasBlob() { return new Promise(r => $("canvas").toBlob(r, "image/png")); }
  async function downloadImage() {
    const blob = await canvasBlob(), url = URL.createObjectURL(blob), a = document.createElement("a");
    a.href = url; a.download = `subah-bakhair-${Date.now()}.png`; document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000); toast("تصویر محفوظ ہو گئی ✓");
  }
  async function shareImage() {
    const blob = await canvasBlob(), file = new File([blob], "subah-bakhair.png", { type: "image/png" });
    if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file], text: plain() }); } catch (_) {} }
    else downloadImage();
  }

  // ---------- theme ----------
  const THEME_ICON = { auto: "#i-auto", light: "#i-sun", dark: "#i-moon" };
  const THEME_LABEL = { auto: "خودکار", light: "روشن", dark: "تاریک" };
  function applyTheme() {
    const root = document.documentElement;
    if (prefs.theme === "auto") root.removeAttribute("data-theme"); else root.setAttribute("data-theme", prefs.theme);
    $("themeBtn").querySelector("use").setAttribute("href", THEME_ICON[prefs.theme]);
    $("themeBtn").title = "تھیم: " + THEME_LABEL[prefs.theme];
  }

  // ---------- font ----------
  const FONT_VAR = { nastaliq: "var(--f-nastaliq)", gulzar: "var(--f-gulzar)", naskh: '"Noto Naskh Arabic", serif' };
  function applyFont() {
    document.documentElement.style.setProperty("--msg-font", FONT_VAR[prefs.font] || FONT_VAR.nastaliq);
    document.documentElement.style.setProperty("--msg-size", prefs.size + "rem");
    $("font").value = prefs.font;
  }

  // ---------- personalisation panel ----------
  function segSet(name, v) {
    document.querySelectorAll(`.seg[data-name="${name}"] button`).forEach(b => b.setAttribute("aria-checked", b.dataset.v === v));
  }
  function syncPanel() {
    const rel = RELATIONS[prefs.relation] || {};
    segSet("gender", rel.gender || prefs.gender); segSet("register", prefs.register); segSet("length", prefs.length);
    document.querySelector('.seg[data-name="gender"]').classList.toggle("locked", !!rel.gender);
    $("name").disabled = !!rel.fixed;
    $("name").placeholder = rel.fixed ? `«${rel.alone}» کہہ کر مخاطب کیا جائے گا` : "مثلاً علی، سارہ (اختیاری)";
    const bits = [];
    const voc = window.CATEGORIES.vocative(prefs.relation, prefs.name, rel.gender || prefs.gender || "m");
    if (voc) bits.push(voc); else if (prefs.relation) bits.push(rel.label);
    bits.push(prefs.register || (byKey[prefs.cat] || {}).register || "آپ");
    bits.push({ short: "مختصر", medium: "درمیانہ", long: "تفصیلی" }[prefs.length]);
    $("panelSummary").textContent = bits.join(" · ");
  }

  function buildUI() {
    // categories
    const nav = $("cats");
    for (const c of CATS) {
      const b = document.createElement("button"); b.className = "chip"; b.dataset.k = c.key; b.title = c.desc;
      b.innerHTML = `<span class="ico" aria-hidden="true">${c.icon}</span>`; b.append(c.key);
      b.setAttribute("aria-pressed", c.key === prefs.cat);
      b.onclick = () => selectCat(c.key);
      nav.append(b);
    }
    // relations
    const sel = $("relation");
    for (const [k, r] of Object.entries(RELATIONS)) { const o = document.createElement("option"); o.value = k; o.textContent = r.label; sel.append(o); }
    sel.value = prefs.relation; $("name").value = prefs.name; $("emoji").checked = prefs.emoji; $("sign").value = prefs.sign;

    // image themes
    for (const [k, t] of Object.entries(Card.THEMES)) {
      const b = document.createElement("button"); b.type = "button"; b.setAttribute("role", "radio"); b.dataset.v = k;
      b.style.background = t.swatch; b.title = t.name; b.setAttribute("aria-label", t.name);
      b.setAttribute("aria-checked", k === prefs.imgTheme);
      b.onclick = () => { prefs.imgTheme = k; savePrefs(); document.querySelectorAll("#swatches button").forEach(x => x.setAttribute("aria-checked", x === b)); drawImage(); };
      $("swatches").append(b);
    }
    segSet("size", prefs.imgSize);
  }

  function selectCat(k) {
    prefs.cat = k; savePrefs();
    document.querySelectorAll(".chip").forEach(b => b.setAttribute("aria-pressed", b.dataset.k === k));
    const chip = document.querySelector(`.chip[data-k="${k}"]`);
    if (chip) chip.scrollIntoView({ inline: "nearest", block: "nearest", behavior: REDUCED ? "auto" : "smooth" });
    syncPanel(); generate();
  }

  function bind() {
    $("gen").onclick = generate;
    $("errRetry").onclick = () => { clearInterval(errTimer); generate(); };
    $("copy").onclick = copy; $("wa").onclick = whatsapp; $("share").onclick = share;
    $("fav").onclick = toggleFav; $("speak").onclick = speak; $("imgBtn").onclick = openImage;
    $("tabHist").onclick = () => setTab("hist"); $("tabFav").onclick = () => setTab("fav");
    $("undo").onclick = () => { if (undoText) { setMessage(undoText.t, undoText.src || "edited", { animate: false }); undoText = null; $("undo").hidden = true; } };
    document.querySelectorAll(".refine button").forEach(b => (b.onclick = () => { exitEdit(); refine(b.dataset.a); }));
    $("editBtn").onclick = () => ($("msgEdit").hidden ? enterEdit() : exitEdit());
    $("msgEdit").addEventListener("keydown", e => { if (e.key === "Escape") exitEdit(false); });

    $("themeBtn").onclick = () => { prefs.theme = { auto: "light", light: "dark", dark: "auto" }[prefs.theme]; savePrefs(); applyTheme(); };
    $("font").onchange = e => { prefs.font = e.target.value; savePrefs(); applyFont(); };
    $("bigger").onclick = () => { prefs.size = Math.min(2.2, +(prefs.size + .1).toFixed(2)); savePrefs(); applyFont(); };
    $("smaller").onclick = () => { prefs.size = Math.max(1, +(prefs.size - .1).toFixed(2)); savePrefs(); applyFont(); };

    $("name").oninput = e => { prefs.name = e.target.value; savePrefs(); syncPanel(); };
    $("relation").onchange = e => {
      prefs.relation = e.target.value;
      const r = RELATIONS[prefs.relation] || {}; if (r.gender) prefs.gender = r.gender;
      savePrefs(); syncPanel();
    };
    $("emoji").onchange = e => { prefs.emoji = e.target.checked; savePrefs(); };
    document.querySelectorAll(".seg").forEach(seg => seg.addEventListener("click", e => {
      const b = e.target.closest("button"); if (!b) return;
      const name = seg.dataset.name;
      if (name === "size") { prefs.imgSize = b.dataset.v; segSet("size", prefs.imgSize); savePrefs(); return drawImage(); }
      prefs[name] = b.dataset.v; savePrefs(); syncPanel();
    }));
    $("sign").oninput = e => { prefs.sign = e.target.value; savePrefs(); clearTimeout(bind.t); bind.t = setTimeout(drawImage, 250); };
    $("dlBtn").onclick = downloadImage; $("shareImg").onclick = shareImage;
    $("imgDialog").addEventListener("click", e => { if (e.target === $("imgDialog")) $("imgDialog").close(); });

    // keyboard shortcuts (ignored while typing)
    document.addEventListener("keydown", e => {
      if (e.target.closest("input, textarea, select") || e.metaKey || e.ctrlKey || e.altKey || $("imgDialog").open) return;
      const k = e.key.toLowerCase();
      if (k === "n") { e.preventDefault(); generate(); }
      else if (k === "c") { e.preventDefault(); copy(); }
      else if (k === "f") { e.preventDefault(); toggleFav(); }
    });
    window.addEventListener("online", () => setBadge(current.src));
    window.addEventListener("offline", () => setBadge(current.src));
  }

  function hero() {
    const now = new Date(), d = Urdu.dateLine(now);
    $("greet").textContent = Urdu.timeGreeting(now);
    $("gdate").textContent = d.gregorian; $("hdate").textContent = d.hijri;
    const occ = Urdu.occasion(now), btn = $("occasion");
    if (occ && byKey[occ.key] && prefs.cat !== occ.key) {
      btn.hidden = false; btn.textContent = occ.label;
      btn.onclick = () => { btn.hidden = true; selectCat(occ.key); };
    }
  }

  // ---------- boot ----------
  applyTheme(); applyFont(); buildUI(); syncPanel(); bind(); hero(); renderList();
  if ("speechSynthesis" in window) speechSynthesis.onvoiceschanged = findVoice;
  generate();

  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
  }
})();
