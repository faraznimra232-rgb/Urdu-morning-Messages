const test = require("node:test"), assert = require("node:assert");
const fs = require("node:fs"), os = require("node:os"), path = require("node:path");
const { createLimiter } = require("../lib/limiter");
const { createPool } = require("../lib/pool");

const until = async (f, ms = 3000) => { const t = Date.now(); while (!f()) { if (Date.now() - t > ms) throw new Error("timeout"); await new Promise(r => setTimeout(r, 5)); } };
const quiet = { warn() {}, log() {} };
const plain = { category: "عمومی", gender: "", register: "", length: "medium", emoji: true, name: "", relation: "", avoid: [], refine: null };

test("limiter: runs max at once, queues, refuses when the queue is full, never overshoots", async () => {
  const L = createLimiter(1, 1);
  let running = 0, peak = 0; const gates = [];
  const job = () => L.run(async () => { running++; peak = Math.max(peak, running); await new Promise(r => gates.push(r)); running--; return "ok"; });
  const a = job(), b = job();
  await until(() => gates.length === 1);
  assert.strictEqual(L.waiting, 1);
  await assert.rejects(job(), e => e.kind === "busy");
  gates.shift()(); await a;               // A finishes → B starts
  await until(() => gates.length === 1); gates.shift()(); await b;
  assert.strictEqual(peak, 1); assert.strictEqual(L.active, 0); assert.strictEqual(L.waiting, 0);
});

test("pool: only plain requests are stocked", () => {
  const p = createPool({ size: 2, make: async () => ({}), log: quiet });
  assert.ok(p.keyFor(plain));
  assert.strictEqual(p.keyFor({ ...plain, name: "علی" }), null);
  assert.strictEqual(p.keyFor({ ...plain, relation: "ماں" }), null);
  assert.strictEqual(p.keyFor({ ...plain, refine: { action: "x", text: "y" } }), null);
});

test("pool: fills in the background up to its size, hands out each message once, skips ones to avoid", async () => {
  let n = 0;
  const p = createPool({ size: 3, make: async () => ({ message: `m${++n}`, model: "g" }), log: quiet });
  const key = p.keyFor(plain);
  assert.strictEqual(p.take(key), null);        // nothing yet
  p.want(key, plain); p.kick();
  await until(() => p.stats().ready === 3);
  assert.strictEqual(p.take(key, ["m1"]).message, "m2"); // m1 was just shown to this user
  assert.strictEqual(p.take(key).message, "m1");
  assert.strictEqual(p.take(key).message, "m3");
  assert.strictEqual(p.take(key), null);
  p.kick(); await until(() => p.stats().ready === 3);    // topped up again
});

test("pool: does not compete with live users, and survives a restart (saved to disk)", async () => {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "pool-")), "pool.json");
  let busy = true, n = 0;
  const p = createPool({ file, size: 2, pollMs: 10, idle: () => !busy, make: async () => ({ message: `x${++n}`, model: "g" }), log: quiet });
  const key = p.keyFor(plain); p.want(key, plain); p.kick();
  await new Promise(r => setTimeout(r, 80)); assert.strictEqual(n, 0, "waits while a live request is running");
  busy = false; await until(() => p.stats().ready === 2);
  const again = createPool({ file, size: 2, make: async () => ({}), log: quiet });
  assert.strictEqual(again.stats().ready, 2); assert.ok(again.take(key));
});

test("pool: an AI error pauses refilling instead of looping; repeated duplicates stop too", async () => {
  let calls = 0;
  const bad = createPool({ size: 2, retryMs: 1e9, make: async () => { calls++; throw new Error("ai_down"); }, log: quiet });
  const key = bad.keyFor(plain); bad.want(key, plain); bad.kick();
  await new Promise(r => setTimeout(r, 50)); assert.strictEqual(calls, 1);
  let d = 0;
  const same = createPool({ size: 3, make: async () => { d++; return { message: "same", model: "g" }; }, log: quiet });
  same.want(key, plain); same.kick(); await new Promise(r => setTimeout(r, 50));
  assert.ok(d <= 5 && same.stats().ready === 1, `duplicates stopped after ${d} tries`);
});
