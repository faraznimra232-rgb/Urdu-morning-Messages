const path = require("path");
require("dotenv").config({ path: path.join(__dirname, ".env") }); // always this folder's .env, whatever directory you start from
const express = require("express"), cors = require("cors");
const Compose = require("./public/js/compose.js"); // offline template library (fallback when the AI is unavailable)
const { generate, cleanOpts, modelStatus, aiEnabled, warmup, PROVIDER, CATS, RELATIONS, REFINE } = require("./lib/generate");
const { createLimiter } = require("./lib/limiter");
const { createPool } = require("./lib/pool");

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1); // correct client IPs behind Render / Railway / nginx

// --- security headers (no inline scripts anywhere, so a strict CSP works) ---
app.use((req, res, next) => {
  res.set({
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "DENY",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "Content-Security-Policy": [
      "default-src 'self'", "script-src 'self'", "connect-src 'self'",
      "style-src 'self' 'unsafe-inline'", "font-src 'self'", "img-src 'self' data: blob:",
      "base-uri 'none'", "frame-ancestors 'none'"
    ].join("; ")
  });
  next();
});

// --- CORS: same-origin, the Chrome extension, and anything listed in ALLOWED_ORIGINS ---
const allowed = (process.env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
app.use("/api", cors({
  origin: (origin, cb) => cb(null, !origin || origin.startsWith("chrome-extension://") || allowed.includes(origin) || allowed.includes("*"))
}));
app.use(express.json({ limit: "20kb" }));

// --- static files; service worker must never be cached by the browser ---
const fs = require("fs");
const dist = path.join(__dirname, "dist");
const WEB = fs.existsSync(path.join(dist, "index.html")) ? dist : path.join(__dirname, "public"); // React build if present
app.use(express.static(WEB, {
  setHeaders(res, file) {
    if (file.endsWith("sw.js") || file.endsWith(".html")) res.set("Cache-Control", "no-cache");
    else res.set("Cache-Control", "public, max-age=3600");
  }
}));

// --- per-IP rate limit (sliding window), with periodic cleanup so memory can't grow forever ---
const LIMIT = Number(process.env.RATE_LIMIT || 30), WINDOW = 60_000, hits = new Map();
setInterval(() => {
  const now = Date.now();
  for (const [k, a] of hits) { const f = a.filter(t => now - t < WINDOW); f.length ? hits.set(k, f) : hits.delete(k); }
}, WINDOW).unref();
function rateLimit(req, res, next) {
  const now = Date.now(), a = (hits.get(req.ip) || []).filter(t => now - t < WINDOW);
  if (a.length >= LIMIT) {
    res.set("Retry-After", Math.ceil((WINDOW - (now - a[0])) / 1000));
    return res.status(429).json({ error: "بہت زیادہ درخواستیں — ایک منٹ بعد کوشش کریں" });
  }
  a.push(now); hits.set(req.ip, a); next();
}

// --- many visitors on one PC: cap parallel generations, and keep a stock of ready messages so most taps are instant ---
// a cloud API handles many at once; a single local PC does not
const limiter = createLimiter(Number(process.env.MAX_LIVE || (PROVIDER === "groq" ? 8 : 2)), Number(process.env.QUEUE_MAX || (PROVIDER === "groq" ? 24 : 4)));
const POOL_SIZE = Number(process.env.POOL_SIZE ?? (PROVIDER === "ollama" ? 5 : 0)); // 0 = off (default for Groq so the API quota is not used up)
const pool = POOL_SIZE > 0 && aiEnabled() ? createPool({
  file: path.join(__dirname, "data", "pool.json"), size: POOL_SIZE,
  make: o => limiter.run(() => generate(o)),
  idle: () => limiter.active === 0 && limiter.waiting === 0
}) : null;

// One entry point for both routes: a ready-made message first (instant), otherwise write one now.
async function produce(body, onToken) {
  const o = cleanOpts(body);
  const key = pool && !o.refine ? pool.keyFor(o) : null;
  if (key) {
    const hit = pool.take(key, o.avoid);
    if (hit) { pool.kick(); return { message: hit.message, model: hit.model, source: "ai", pooled: true }; }
    pool.want(key, o);
  }
  const r = await limiter.run(() => generate(o, onToken));
  if (key) pool.kick(); // restock in the background for the next visitor
  return { message: r.message, model: r.model, source: "ai" };
}

function badRequest(body) {
  if (body.category && !CATS.some(c => c.key === body.category)) return "Unknown category";
  if (body.refine && (!REFINE.includes(body.refine.action) || !String(body.refine.text || "").trim())) return "Invalid refine request";
  return null;
}

// Same as /api/generate, but sends the text piece by piece (Server-Sent Events) so a slow local model feels much faster.
app.post("/api/generate/stream", rateLimit, async (req, res) => {
  const body = req.body || {};
  const bad = badRequest(body);
  if (bad) return res.status(400).json({ error: bad });
  res.set({ "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no" });
  res.flushHeaders();
  const send = o => { if (!res.writableEnded && !res.destroyed) res.write(`data: ${JSON.stringify(o)}\n\n`); };
  const ping = setInterval(() => { if (!res.writableEnded && !res.destroyed) res.write(": ping\n\n"); }, 15000);
  try {
    const { message, model, pooled } = await produce(body, t => send(t === null ? { reset: 1 } : { t }));
    send({ done: 1, message, model, pooled });
  } catch (e) {
    console.error("[generate]", e.message);
    const kind = e.kind || "failed";
    if (body.refine) send({ error: 1, kind });
    else { const o = cleanOpts(body); send({ done: 1, message: Compose.build(o.category, o), model: null, source: "offline", reason: kind }); }
  } finally { clearInterval(ping); res.end(); }
});

app.post("/api/generate", rateLimit, async (req, res) => {
  const body = req.body || {};
  const bad = badRequest(body);
  if (bad) return res.status(400).json({ error: bad });
  const started = Date.now();
  try {
    const { message, model } = await produce(body);
    res.set("Server-Timing", `gen;dur=${Date.now() - started}`);
    res.json({ message, source: "ai", model });
  } catch (e) {
    console.error("[generate]", e.message);
    const kind = e.kind || "failed";
    // AI unavailable: still give the user a real message from the offline template library (refinements need the AI)
    if (!body.refine) {
      const o = cleanOpts(body);
      return res.json({ message: Compose.build(o.category, o), source: "offline", reason: kind });
    }
    res.status(kind === "rate_limit" ? 429 : kind === "busy" ? 503 : 502).json({ error: "Generation failed", kind });
  }
});

app.get("/api/meta", (_, res) => res.json({
  categories: CATS.map(({ key, icon, desc, register }) => ({ key, icon, desc, register })),
  relations: Object.entries(RELATIONS).map(([key, r]) => ({ key, label: r.label, gender: r.gender || null })),
  refine: REFINE,
  ai: aiEnabled()
}));
app.get("/api/categories", (_, res) => res.json(CATS.map(c => c.key))); // kept for old clients
app.get("/healthz", (_, res) => res.type("text").send("ok")); // for the host's health check: instant, never calls the AI
app.get("/api/health", async (_, res) => {
  let st;
  try { st = await modelStatus(); } catch (e) { st = { ai: false, provider: PROVIDER, models: [], error: e.message }; }
  res.json({ ok: true, ui: WEB === dist ? "react" : "classic", ...st, queue: { running: limiter.active, waiting: limiter.waiting }, stock: pool ? pool.stats() : null, uptime: Math.round(process.uptime()) });
});

app.use("/api", (_, res) => res.status(404).json({ error: "Not found" }));
app.use((err, req, res, _next) => { // e.g. malformed JSON
  res.status(err.status || 500).json({ error: err.type === "entity.parse.failed" ? "Invalid JSON" : "Server error" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`صبح بخیر → http://localhost:${PORT}`);
  console.log(WEB === dist ? "Web app: React build (dist/)" : "Web app: classic UI (public/) — run `npm run build` for the React UI");
  if (!aiEnabled()) console.warn("GROQ_API_KEY not set — using offline templates. Set it, or use AI_PROVIDER=ollama for a free local model.");
  else modelStatus().then(s => {
    if (s.models.length) {
      console.log(`AI (${s.provider}): ${s.models.join(" → ")}`);
      warmup().then(() => { if (pool) { pool.want(pool.keyFor(cleanOpts({})), cleanOpts({})); pool.kick(); } }); // start stocking the default message
    }
    else console.warn(PROVIDER === "ollama" ? `⚠ ${s.error || "Ollama has no usable model"}` : "⚠ No usable Groq model found for this key");
  });
});
