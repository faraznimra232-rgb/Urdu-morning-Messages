// Runs automatically before `npm start`: builds the React app (client/ → dist/) if it is missing or older than the source.
// Never blocks the server: if the build is impossible (e.g. `npm install` not run yet) the classic UI in public/ is used.
const fs = require("fs"), path = require("path"), { spawnSync } = require("child_process");
const root = path.join(__dirname, ".."), client = path.join(root, "client"), distIndex = path.join(root, "dist", "index.html");

function newest(dir) {
  let t = 0;
  for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, f.name);
    t = Math.max(t, f.isDirectory() ? newest(p) : fs.statSync(p).mtimeMs);
  }
  return t;
}

if (!fs.existsSync(client)) process.exit(0);
const stale = !fs.existsSync(distIndex) || fs.statSync(distIndex).mtimeMs < newest(client);
if (!stale) process.exit(0);

let vite;
try {
  // vite hides its bin file from require.resolve (package "exports"), so locate it through package.json instead
  vite = path.join(path.dirname(require.resolve("vite/package.json", { paths: [root] })), "bin", "vite.js");
  if (!fs.existsSync(vite)) throw new Error("vite bin not found");
} catch { console.warn("[build] vite is not installed — run `npm install` once. Starting with the classic UI for now."); process.exit(0); }

console.log("[build] building the React app…");
const r = spawnSync(process.execPath, [vite, "build", client], { cwd: root, stdio: "inherit" });
if (r.status !== 0) console.warn("[build] build failed — starting with the classic UI. Run `npm run build` to see the error.");
