const test = require("node:test"), assert = require("node:assert");
const U = require("../public/js/urdu.js");
const C = require("../public/js/categories.js");
const Compose = require("../public/js/compose.js");
const { cleanOpts } = require("../lib/generate.js");
test("normalize fixes Arabic letters and Latin punctuation", () => {
  assert.strictEqual(U.normalize("كيا حال ہے?"), "کیا حال ہے؟");
  assert.strictEqual(U.normalize("اللہ تعالیٰ آپ کي مدد کرے."), "اللہ تعالیٰ آپ کی مدد کرے۔");
  assert.strictEqual(U.normalize("شکریه,دوست"), "شکریہ، دوست");
});
test("Quranic Arabic is detected and left untouched; Urdu with a few diacritics is not", () => {
  const ayah = "رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي";
  assert.ok(U.isArabic(ayah));
  assert.strictEqual(U.normalize(ayah), ayah);
  for (const l of ["رزقِ حلال فوراً ملے", "اللہ تعالیٰ", "صبحِ نو مبارک"]) assert.ok(!U.isArabic(l), l);
});
test("every stored verse is vowelled Arabic with a reference", () => {
  for (const c of C.CATS) for (const v of c.verses || []) { assert.ok(U.isArabic(v.ar), v.ar); assert.ok(v.ref && v.ur); }
});
test("no template line uses Arabic ي/ك/ه or Latin punctuation", () => {
  for (const c of C.CATS) for (const l of [...c.open, ...c.body, ...c.close])
    assert.ok(!/[يكه?]/.test(l), `${c.key}: ${l}`);
});
test("vocatives", () => {
  assert.strictEqual(C.vocative("بھائی", "علی"), "علی بھائی");
  assert.strictEqual(C.vocative("امی", "کچھ بھی"), "امی جان");
  assert.strictEqual(C.vocative("ساتھی", "سارہ", "f"), "سارہ صاحبہ");
  assert.strictEqual(C.vocative("", ""), "");
});
test("offline composer respects gender and never leaves tokens", () => {
  for (const c of C.CATS) for (const g of ["m", "f"]) for (const length of ["short", "medium", "long"]) {
    const m = Compose.build(c.key, { gender: g, length, name: "سارہ" });
    assert.ok(!/[{}|]/.test(m), m);
    assert.ok(U.urduRatio(m) > 0.9);
  }
  assert.match(Compose.build("حوصلہ افزائی", { gender: "f", length: "long" }) + Compose.build("حوصلہ افزائی", { gender: "f", length: "long" }), /سکتی|سمجھتی|تھکی|ہاری|صبح|کام/);
});
test("cleanOpts sanitises input", () => {
  const o = cleanOpts({ category: "nope", name: "<script>x".repeat(20), length: "huge", avoid: "x", refine: { action: "hack" } });
  assert.strictEqual(o.category, "عمومی");
  assert.ok(o.name.length <= 40 && !o.name.includes("<"));
  assert.strictEqual(o.length, "medium");
  assert.deepStrictEqual(o.avoid, []);
  assert.strictEqual(o.refine, null);
});
test("dates", () => {
  const d = U.dateLine(new Date(2026, 8, 30));
  assert.strictEqual(d.gregorian, "بدھ، ۳۰ ستمبر ۲۰۲۶");
  assert.match(d.hijri, /ربیع الثانی ۱۴۴۸ ہجری$/);
  assert.strictEqual(U.occasion(new Date(2026, 9, 2)).key, "جمعہ مبارک"); // a Friday
});


