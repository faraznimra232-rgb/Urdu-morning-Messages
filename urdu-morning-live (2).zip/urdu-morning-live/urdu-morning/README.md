# صبح بخیر پیغامات — Urdu Morning Messages (v2)

Fresh, well-written Urdu greetings every time, for the web, phone (PWA), a Chrome extension and a daily Telegram bot.
Messages are written by a **local Ollama model (Gemma 4 by default, no API key or bill)** under a strict Urdu style guide. Set `AI_PROVIDER=groq` to use the Groq cloud API instead (auto-picks a live model: gpt-oss-120b → Qwen 3.6 → gpt-oss-20b). With no internet or no API key, the app
falls back to a hand-written, gender-aware template library.

## What's new in v2
**Design**
- New dawn-sky design with light, dark and auto themes, built mobile-first, with a sticky action bar on phones
- Self-hosted Urdu fonts: Noto Nastaliq Urdu, Gulzar and Noto Naskh Arabic, plus Amiri for Quranic Arabic. They work offline.
- Font picker and text size control. Arabic lines are shown in Naskh (Amiri) and Urdu in Nastaliq.
- Time-of-day greeting, plus the Gregorian and Hijri dates in Urdu numerals (۳۰ ستمبر ۲۰۲۶ • ۱۹ ربیع الثانی ۱۴۴۸)
- Smart occasion banner: Friday → جمعہ مبارک, Ramadan → رمضان, Eid days → عید مبارک

**Features**
- 12 categories: اسلامی، جمعہ مبارک، رمضان المبارک، عید مبارک، عمومی، حوصلہ افزائی، دوستوں کے لیے، گھر والوں کے لیے، شریکِ حیات، شاعرانہ، دفتر کے ساتھی، بزرگوں کے لیے
- Personalisation:
  - name and relation, with proper vocatives (علی بھائی، امی جان، سارہ صاحبہ)
  - the reader's gender, for correct verb agreement (سکتے / سکتی)
  - آپ / تم register
  - length (مختصر، درمیانہ، تفصیلی)
  - emoji on/off
- AI refine: مختصر کریں، مزید پیار بھرا، زیادہ مؤدبانہ، شعر شامل کریں، دعا شامل کریں، **اصلاح کریں** (proofreads your own text), with undo
- Inline editing, with automatic spelling and punctuation correction on save
- **Status image maker**: 5 designs (فجر، سبز، رات، گلاب، کاغذ), square or 9:16 story size, optional signature. Download it, or share it straight to WhatsApp.
- Favourites and a history of 30 messages, both saved on the device
- Text-to-speech, when the device has an Urdu voice
- Keyboard shortcuts: `N` new message, `C` copy, `F` favourite

**Urdu quality**
- The AI follows a style guide:
  - Urdu letters ی ک ہ, not the Arabic ي ك ه
  - Urdu punctuation ۔ ؟ ،
  - correct izafat
  - consistent آپ/تم
  - gender agreement
  - vocatives like دوستو, not دوستوں
- Every AI output is cleaned automatically. English preambles are removed and Arabic letters are fixed. Fully vowelled Quranic Arabic is detected and left untouched.
- Quran verses and duas in the templates are authentic, fully vowelled, and carry an Urdu meaning and an exact reference (e.g. سورۂ طٰہٰ، آیات ۲۵–۲۶).
- The AI is told never to invent hadith, and never to quote or attribute poetry to real poets. Misattribution to Iqbal and Ghalib is very common.

**Engineering**
- One source of truth, `public/js/categories.js`, used by the server, the browser, the extension and the bot
- Groq model auto-discovery (skips retired models), timeout, retry, fallback chain, and an output check that rejects non-Urdu output
- Strict CSP, security headers, a rate limiter that no longer leaks memory, `trust proxy`, and input sanitising
- Service worker v2: precaches the app shell and removes old caches
- Bot: rotates categories daily, sends special messages on Friday, Ramadan and Eid, retries, and falls back to templates if AI fails
- The extension is **built from the web app** (`npm run build:ext`), so the two can't drift apart
- Unit tests for the Urdu logic (`npm test`)

## Setup
```bash
# 1. local AI (once) — install Ollama from https://ollama.com, then:
ollama pull gemma4:e4b       # 8-16 GB RAM. 24 GB+ RAM: ollama pull gemma4:26b (better Urdu) and set OLLAMA_MODEL=gemma4:26b

# 2. the app
npm install                  # use install (not ci): installs React + Vite too
cp .env.example .env         # AI_PROVIDER=ollama is already the default
npm start                    # builds the React app automatically when needed, then http://localhost:3000
npm test
```
The first message after starting can take a while because the model loads into memory; the server warms it up at startup. If Ollama is not running, the app says so in Urdu and offers a retry.

## PWA (phone)
Deploy to any HTTPS host (Render, Railway, Fly.io, a VPS). Then open the URL in Chrome on Android, open the ⋮ menu and choose *Install app*.

## Chrome extension
1. Set `API_BASE` in `extension/config.js` to your server URL. If it is `https://…`, also add that URL to `host_permissions` in `extension/manifest.json`.
2. Run `npm run build:ext` after any change to `public/`.
3. Open `chrome://extensions`, turn on Developer mode, click *Load unpacked* and choose the `extension` folder.

## Daily auto-send (Telegram)
1. Create a bot with @BotFather and copy its token.
2. Get your chat id: message @userinfobot, or add the bot to a group.
3. Fill in the `TELEGRAM_*`, `SEND_TIME` and `SEND_CATEGORY` values in `.env`.
4. Run `npm run bot`. To test it right away, run `npm run bot:now`. Keep it running with pm2 or on a hosted worker.

WhatsApp auto-send needs the official Business API (Meta Cloud API or Twilio). In the app, the WhatsApp button opens a share link instead.

## Add a category
Add one object to `CATS` in `public/js/categories.js` (prompt + offline pools), then run `npm test` and `npm run build:ext`.

## Security
The API key lives only in `.env` on the server. **Never zip, commit or share `.env`.**


## Slow on your PC?
- The message now appears word by word while the model writes (streaming), so you are not staring at a blank card.
- The terminal prints a line like `[ollama] gemma4:e4b: prompt 900 tok 12.0s | answer 30 tok 3.0s` after each message, so you can see where the time goes. A big "prompt" time means a shorter prompt will help: set `OLLAMA_SAMPLES=1` and `OLLAMA_AVOID=1` in `.env`.
- A smaller model (`gemma4:e2b`) is about 2x faster but writes weaker Urdu. A GPU is the biggest speed-up.


## Windows: one click
Double-click `start.cmd` — it installs packages (first time), rebuilds the web app and starts the server. Open `http://localhost:3000/api/health`: `"ui":"react"` means the new interface is being served, `"classic"` means the old one.

## React frontend (v3)

The web app now lives in `client/` (React + Vite). `npm start` builds it into `dist/` automatically the first time and whenever `client/` changed (`scripts/ensure-build.js`). If the build is not possible, the server falls back to the classic UI in `public/` (which the Chrome extension build also uses).

```
npm run build     # build client/ into dist/ by hand (shows build errors)
npm run client    # optional: Vite hot-reload on :5173, proxies /api to :3000
```
When the AI is down (Ollama not running, no model, timeout) the server returns a message from the offline template library and the card shows the "آف لائن نمونہ" badge instead of an error. Refinements (shorter / warmer / …) need the AI.

SEO: before deploying, replace `https://your-domain.com` in `client/index.html`, `client/public/robots.txt` and `client/public/sitemap.xml` with your real domain.


## Run it from your own PC and share a link
1. `start.cmd` (keep it open) — the app runs on `http://localhost:3000`.
2. `share.cmd` in a second window — prints a public `https://….trycloudflare.com` link. Send it to anyone; it works on their phone or PC. The link changes each time you restart `share.cmd`.
3. Same Wi-Fi only (no internet link needed): open `http://YOUR-PC-IP:3000` (`ipconfig` → IPv4) and allow Node.js in Windows Firewall when asked.

Your PC must stay on, awake and online. Only the web app is exposed — Ollama itself (port 11434), your `.env` and the Telegram bot token are not reachable from the link.
For a permanent link use a Cloudflare named tunnel (needs your own domain), ngrok's free static domain, or Tailscale Funnel.

Speed with many visitors: the server keeps a stock of ready messages (`POOL_SIZE`), limits parallel generations (`MAX_LIVE`) and answers with an offline template when the queue is full (`QUEUE_MAX`). `http://localhost:3000/api/health` shows `stock` and `queue`.


## Put it on a live server (Groq API, no Ollama)
A normal hosting server has no GPU, so use the Groq API there (`AI_PROVIDER=groq`, `GROQ_API_KEY=...`).
- **Render:** push the project to GitHub (without `.env`), then New → Blueprint (uses `render.yaml`). Paste `GROQ_API_KEY` in the dashboard.
  The free plan sleeps after 15 min idle (about 1 min to wake); the always-on plan starts at about $7/month.
- **Railway / Fly.io / Koyeb / any VPS:** use the `Dockerfile` (`docker build -t urdu-morning .`, `docker run -p 3000:3000 --env-file .env urdu-morning`). Put Caddy or nginx in front for HTTPS on a VPS.
- Build = `npm install --include=dev && npm run build`, start = `node server.js`, health check = `/healthz`.
- If the AI is slow, rate-limited or down, visitors still get an offline template message instead of an error.
- The Telegram bot (`npm run bot`) is a second always-running process; on Render that needs a separate Background Worker (paid), on a VPS run it with pm2 or a second container.
