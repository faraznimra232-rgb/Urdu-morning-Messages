import { useState, useEffect, useRef, useCallback } from "react";
import { PHRASES, THOUGHTS, WORDS, FEATURES, FAQ, SLIDES } from "./content.js";

const { CATS, RELATIONS, byKey } = window.CATEGORIES;
const Urdu = window.Urdu, Card = window.Card;
const API = (window.API_BASE || "").replace(/\/$/, "");
const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
const REF = /^\(.*\)$|\((?:سورۃ|سورۂ|سنن|صحیح|درود|صحابۂ)[^)]*\)$/;
const DUA = "اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ";

const store = {
  get(k, d) { try { const v = localStorage.getItem("um." + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("um." + k, JSON.stringify(v)); } catch { /* private mode */ } }
};
const ERR = {
  offline: "انٹرنیٹ سے رابطہ نہیں ہے۔ کنکشن چیک کر کے دوبارہ کوشش کریں۔",
  rate_limit: "AI ابھی مصروف ہے (فی منٹ کی حد پوری ہو گئی)۔ چند سیکنڈ بعد دوبارہ کوشش کریں۔",
  auth: "سرور کی API کلید درست نہیں۔ .env میں GROQ_API_KEY چیک کریں۔",
  busy: "سرور اس وقت مصروف ہے۔ تھوڑی دیر بعد کوشش کریں۔",
  ai_down: "لوکل AI (Ollama) چل نہیں رہا۔ ٹرمنل میں ollama serve چلائیں اور دوبارہ کوشش کریں۔",
  no_model: "Ollama میں کوئی ماڈل موجود نہیں۔ ٹرمنل میں ollama pull gemma4:e4b چلائیں۔",
  timeout: "AI نے جواب دینے میں بہت دیر کر دی۔ دوبارہ کوشش کریں۔",
  bad_output: "AI کا جواب درست اردو میں نہیں تھا۔ دوبارہ کوشش کریں۔",
  server: "سرور سے رابطہ نہیں ہو سکا۔ کیا سرور چل رہا ہے؟ (npm start)",
  failed: "پیغام نہیں بن سکا۔ دوبارہ کوشش کریں۔"
};
const FONT_VAR = { nastaliq: "var(--f-nastaliq)", gulzar: "var(--f-gulzar)", naskh: '"Noto Naskh Arabic", serif' };

async function api(body) {
  if (!navigator.onLine) throw new Error("offline");
  const ctrl = new AbortController(), to = setTimeout(() => ctrl.abort(), 180000); // a local model can take a while
  try {
    const r = await fetch(API + "/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctrl.signal });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(j.error || "api"), { status: r.status, kind: j.kind || (r.status === 429 ? "rate_limit" : null) });
    return j;
  } finally { clearTimeout(to); }
}
// Same as api(), but the text arrives piece by piece while the local model is still writing (feels much faster).
async function apiStream(body, onPartial) {
  if (!navigator.onLine) throw new Error("offline");
  const ctrl = new AbortController(), to = setTimeout(() => ctrl.abort(), 180000);
  try {
    const r = await fetch(API + "/api/generate/stream", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctrl.signal });
    if (r.status === 404 || (r.ok && !r.body)) return api(body); // older server without streaming
    if (!r.ok) { const j = await r.json().catch(() => ({})); throw Object.assign(new Error(j.error || "api"), { status: r.status, kind: j.kind || (r.status === 429 ? "rate_limit" : null) }); }
    const reader = r.body.getReader(), dec = new TextDecoder();
    let buf = "", text = "", final = null;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n\n")) >= 0) {
        const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
        if (!chunk.startsWith("data:")) continue; // ": ping" keep-alive lines
        const ev = JSON.parse(chunk.slice(5));
        if (ev.reset) { text = ""; onPartial(""); }
        else if (ev.t) { text += ev.t; onPartial(text); }
        else if (ev.done) final = ev;
        else if (ev.error) throw Object.assign(new Error("api"), { kind: ev.kind || "failed" });
      }
    }
    if (!final) throw Object.assign(new Error("api"), { kind: "failed" });
    return { message: final.message, source: final.source, reason: final.reason, streamed: Boolean(text) };
  } finally { clearTimeout(to); }
}
// Shown briefly when the server had to use an offline template instead of the AI.
const OFFLINE_WHY = { busy: "سرور مصروف ہے — آف لائن نمونہ دکھایا گیا", ai_down: "Ollama چل نہیں رہا — آف لائن نمونہ دکھایا گیا", no_model: "Ollama میں ماڈل نہیں — آف لائن نمونہ دکھایا گیا", timeout: "AI نے دیر کی — آف لائن نمونہ دکھایا گیا", auth: "API کلید درست نہیں — آف لائن نمونہ دکھایا گیا" };
const errKind = e => (e.message === "offline" ? "offline" : e.name === "AbortError" ? "timeout" : e.kind || (e.status ? "failed" : "server"));
const timeAgo = d => {
  const m = Math.round((Date.now() - d) / 60000), n = Urdu.toUrduDigits;
  if (m < 1) return "ابھی"; if (m < 60) return `${n(m)} منٹ پہلے`;
  const h = Math.round(m / 60); if (h < 24) return `${n(h)} گھنٹے پہلے`;
  return `${n(Math.round(h / 24))} دن پہلے`;
};

/* ---------- small building blocks ---------- */
const Icon = ({ n }) => <svg aria-hidden="true"><use href={"#i-" + n} /></svg>;

// Button with a tap ripple and a magnetic hover pull
function Btn({ className = "", children, onClick, magnetic, ...p }) {
  const ref = useRef(null);
  const down = e => {
    const b = ref.current; if (!b || b.disabled || REDUCED) return;
    const r = b.getBoundingClientRect(), s = document.createElement("span");
    s.className = "ripple"; s.style.left = e.clientX - r.left + "px"; s.style.top = e.clientY - r.top + "px";
    b.append(s); setTimeout(() => s.remove(), 650);
  };
  const move = e => {
    if (!magnetic || REDUCED) return;
    const r = ref.current.getBoundingClientRect();
    ref.current.style.setProperty("--mx", ((e.clientX - r.left) / r.width - .5).toFixed(2));
    ref.current.style.setProperty("--my", ((e.clientY - r.top) / r.height - .5).toFixed(2));
  };
  const leave = () => { if (ref.current) { ref.current.style.setProperty("--mx", 0); ref.current.style.setProperty("--my", 0); } };
  return <button ref={ref} className={className} onClick={onClick} onPointerDown={down} onMouseMove={move} onMouseLeave={leave} {...p}>{children}</button>;
}

function Rv({ as: T = "div", className = "", k, children, ...p }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!("IntersectionObserver" in window)) { el.classList.add("in"); return; }
    const o = new IntersectionObserver(([e]) => { if (e.isIntersecting) { el.classList.add("in"); o.disconnect(); } }, { threshold: .08 });
    o.observe(el); return () => o.disconnect();
  }, []);
  return <T ref={ref} className={"rv " + className} style={k != null ? { "--k": k } : undefined} {...p}>{children}</T>;
}


/* Hero background slideshow: your own images, auto-advance, arrows, dots, pause on hover/focus */
function HeroSlider() {
  const [ok, setOk] = useState([]);          // slides whose image actually loaded
  const [i, setI] = useState(0);
  const [hold, setHold] = useState(false);
  useEffect(() => {
    let dead = false;
    SLIDES.forEach((s, n) => {
      const put = src => setOk(o => [...o.filter(x => x.n !== n), { n, src, cap: s.cap }].sort((a, b) => a.n - b.n));
      const im = new Image();
      im.onload = () => !dead && put(s.src);
            im.src = s.src;
    });
    return () => { dead = true; };
  }, []);
  const list = ok;
  const go = useCallback(d => setI(x => (x + d + list.length) % list.length), [list.length]);
  useEffect(() => {
    if (hold || list.length < 2 || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = setInterval(() => go(1), 6500);
    return () => clearInterval(t);
  }, [hold, list.length, go]);
  const cur = Math.min(i, Math.max(list.length - 1, 0));
  return (
    <>
      <div className="hero-bg" aria-hidden="true">
        {list.map((s, n) => <div key={s.src} className={"slide" + (n === cur ? " on" : "")} style={{ backgroundImage: `url(${s.src})` }} />)}
        <i className="veil" />
      </div>
      {list.length > 1 && (
        <div className="slider-ui" role="group" aria-roledescription="carousel" aria-label="کتابوں کی تصاویر"
          onMouseEnter={() => setHold(true)} onMouseLeave={() => setHold(false)} onFocus={() => setHold(true)} onBlur={() => setHold(false)}>
          <button className="sl-btn" aria-label="پچھلی تصویر" onClick={() => go(-1)}>›</button>
          <div className="sl-dots">{list.map((s, n) => <button key={s.src} className={"sl-dot" + (n === cur ? " on" : "")} aria-label={"تصویر " + Urdu.toUrduDigits(n + 1)} aria-current={n === cur} onClick={() => setI(n)} />)}</div>
          <button className="sl-btn" aria-label="اگلی تصویر" onClick={() => go(1)}>‹</button>
          {list[cur].cap && <span className="sl-cap" aria-live="polite">{list[cur].cap}</span>}
        </div>
      )}
    </>
  );
}

const Flow = ({ text, cls }) => text.split(/\s+/).filter(Boolean).map((w, i) => <span key={i}><span className={cls} style={{ "--i": i }}>{w}</span>{" "}</span>);

function Thought() {
  const [i, setI] = useState(0), [out, setOut] = useState(false);
  useEffect(() => {
    if (REDUCED) return;
    const t = setInterval(() => { setOut(true); setTimeout(() => { setI(n => (n + 1) % THOUGHTS.length); setOut(false); }, 900); }, 6500);
    return () => clearInterval(t);
  }, []);
  return <p className={"thought" + (out ? " out" : "")} key={i + (out ? "o" : "")}><Flow text={THOUGHTS[i]} cls="w" /></p>;
}

function Message({ text, animate }) {
  let w = 0;
  return text.split("\n").map((line, li) => {
    const cls = "ln" + (Urdu.isArabic(line) ? " ar" : REF.test(line.trim()) ? " ref-line" : "");
    const body = animate && !REDUCED
      ? line.split(/(\s+)/).filter(Boolean).map((p, i) => /^\s+$/.test(p) ? p : <span key={i} className="word" style={{ animationDelay: Math.min(w++ * 35, 1400) + "ms" }}>{p}</span>)
      : line;
    return <span key={li} className={cls}>{body}</span>;
  });
}

function Seg({ name, value, opts, onPick, locked, type }) {
  return (
    <div className={"seg" + (locked ? " locked" : "")} role="radiogroup" aria-label={name}>
      {opts.map(([v, label]) => <button key={v} type={type} role="radio" aria-checked={value === v} onClick={() => onPick(v)}>{label}</button>)}
    </div>
  );
}

/* ---------- app ---------- */
export default function App() {
  const [prefs, setPrefs] = useState(() => {
    const p = { cat: "اسلامی", name: "", relation: "", gender: "", register: "", length: "medium", emoji: true, font: "nastaliq", size: 1.35, theme: "auto", imgTheme: "fajr", imgSize: "square", sign: "", ...store.get("prefs", {}) };
    const q = new URLSearchParams(location.search).get("c");
    if (q && byKey[q]) p.cat = q;
    if (!byKey[p.cat]) p.cat = "اسلامی";
    return p;
  });
  const [cur, setCur] = useState({ t: "", c: prefs.cat, src: "", id: 0, animate: true });
  const [history, setHistory] = useState(() => store.get("history", []));
  const [favs, setFavs] = useState(() => store.get("favs", []));
  const [busy, setBusy] = useState(null);
  const [partial, setPartial] = useState(""); // text of the message while it is still being written
  const [err, setErr] = useState(null);
  const [undo, setUndo] = useState(null);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const [tab, setTab] = useState("hist");
  const [toast, setToast] = useState({ m: "", on: false });
  const [dlg, setDlg] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [burst, setBurst] = useState(0);
  const [occ, setOcc] = useState(() => { const o = Urdu.occasion(new Date()); return o && byKey[o.key] ? o : null; });
  const cardRef = useRef(null), dlgRef = useRef(null), canvasRef = useRef(null), barRef = useRef(null), toastT = useRef();
  const now = new Date(), dl = Urdu.dateLine(now);
  const rel = RELATIONS[prefs.relation] || {};
  const setP = patch => setPrefs(p => ({ ...p, ...patch }));
  const flash = m => { setToast({ m, on: true }); clearTimeout(toastT.current); toastT.current = setTimeout(() => setToast(t => ({ ...t, on: false })), 1800); };

  useEffect(() => store.set("prefs", prefs), [prefs]);
  useEffect(() => store.set("history", history), [history]);
  useEffect(() => store.set("favs", favs), [favs]);
  useEffect(() => {
    const r = document.documentElement;
    if (prefs.theme === "auto") r.removeAttribute("data-theme"); else r.setAttribute("data-theme", prefs.theme);
    r.style.setProperty("--msg-font", FONT_VAR[prefs.font] || FONT_VAR.nastaliq);
    r.style.setProperty("--msg-size", prefs.size + "rem");
  }, [prefs.theme, prefs.font, prefs.size]);

  const options = p => ({ category: p.cat, name: p.name, relation: p.relation, gender: p.gender, register: p.register, length: p.length, emoji: p.emoji });

  const setMessage = (text, src, { animate = true, remember = true } = {}) => {
    stopSpeaking(); setEditing(false);
    setCur(c => ({ t: text, c: prefs.cat, src, id: c.id + 1, animate }));
    if (remember) setHistory(h => [{ t: text, c: prefs.cat, d: Date.now() }, ...h.filter(x => x.t !== text)].slice(0, 30));
  };

  const generate = async (p = prefs) => {
    if (busy) return;
    setBusy("لکھا جا رہا ہے…"); setUndo(null); setPartial("");
    const avoid = history.filter(h => h.c === p.cat).slice(0, 3).map(h => h.t);
    try {
      const { message, source, reason, streamed } = await apiStream({ ...options(p), avoid }, setPartial);
      setBusy(null); setPartial(""); setErr(null); setMessage(message, source === "offline" ? "offline" : "ai", { animate: !streamed });
      if (source === "offline" && OFFLINE_WHY[reason]) flash(OFFLINE_WHY[reason]);
    } catch (e) { setBusy(null); setPartial(""); setErr({ kind: errKind(e), n: 10 }); }
  };
  const gen = useRef(); gen.current = generate;

  const refine = async action => {
    if (busy || !cur.t.trim()) return;
    const text = commit(); setBusy("بہتر بنایا جا رہا ہے…");
    try {
      const { message } = await api({ ...options(prefs), refine: { action, text } });
      setUndo({ t: cur.t, src: cur.src }); setBusy(null); setMessage(message, "ai");
    } catch (e) { setBusy(null); flash(e.kind === "rate_limit" ? "AI ابھی مصروف ہے، چند سیکنڈ بعد کوشش کریں" : "بہتری نہیں ہو سکی، دوبارہ کوشش کریں"); }
  };

  useEffect(() => { gen.current(); }, []); // first message on load
  useEffect(() => {
    if (!err || err.kind !== "rate_limit") return;
    if (err.n <= 0) { gen.current(); return; }
    const t = setTimeout(() => setErr(e => e && { ...e, n: e.n - 1 }), 1000);
    return () => clearTimeout(t);
  }, [err]);
  useEffect(() => { // bounce the card whenever a new message lands
    const el = cardRef.current; if (!el || !cur.id || REDUCED) return;
    el.classList.remove("swap"); void el.offsetWidth; el.classList.add("swap");
  }, [cur.id]);

  // editing
  const commit = () => {
    if (!editing) return cur.t.trim();
    setEditing(false);
    const v = Urdu.normalize(draft);
    if (v && v !== cur.t) { setCur(c => ({ ...c, t: v, src: "edited", animate: false, id: c.id + 1 })); return v.trim(); }
    return cur.t.trim();
  };
  const toggleEdit = () => { if (editing) commit(); else { setDraft(cur.t); setEditing(true); } };

  // share actions
  const copy = async () => {
    const t = commit();
    try { await navigator.clipboard.writeText(t); flash("کاپی ہو گیا ✓"); }
    catch { const ta = document.createElement("textarea"); ta.value = t; document.body.append(ta); ta.select(); const ok = document.execCommand("copy"); ta.remove(); flash(ok ? "کاپی ہو گیا ✓" : "کاپی نہیں ہو سکا"); }
  };
  const whatsapp = () => window.open("https://wa.me/?text=" + encodeURIComponent(commit()), "_blank", "noopener");
  const share = async () => { const t = commit(); if (navigator.share) { try { await navigator.share({ text: t }); } catch { /* cancelled */ } } else copy(); };

  const isFav = cur.t && favs.some(f => f.t === cur.t);
  const toggleFav = () => {
    const t = commit(); if (!t) return;
    if (favs.some(f => f.t === cur.t)) { setFavs(f => f.filter(x => x.t !== cur.t)); flash("پسندیدہ سے ہٹا دیا"); }
    else { setFavs(f => [{ t: cur.t, c: cur.c, d: Date.now() }, ...f]); setBurst(b => b + 1); flash("پسندیدہ میں محفوظ ❤"); }
  };

  // speech
  const stopSpeaking = () => { if ("speechSynthesis" in window) speechSynthesis.cancel(); setSpeaking(false); };
  const speak = () => {
    if (!("speechSynthesis" in window)) return flash("آپ کا براؤزر آواز کی سہولت نہیں رکھتا");
    if (speechSynthesis.speaking) return stopSpeaking();
    const voice = (speechSynthesis.getVoices() || []).find(v => /^ur/i.test(v.lang));
    if (!voice) return flash("اس ڈیوائس پر اردو آواز انسٹال نہیں ہے");
    const u = new SpeechSynthesisUtterance(commit().split("\n").filter(l => !Urdu.isArabic(l)).join("۔ "));
    u.voice = voice; u.lang = voice.lang; u.rate = .92; u.onend = u.onerror = () => setSpeaking(false);
    setSpeaking(true); speechSynthesis.speak(u);
  };

  // image dialog
  const drawImage = useCallback(async () => {
    if (!canvasRef.current || !cur.t) return;
    await Card.render(canvasRef.current, { text: cur.t.trim(), theme: prefs.imgTheme, size: prefs.imgSize, font: prefs.font, sign: prefs.sign.trim(), dateLine: [dl.gregorian, dl.hijri].filter(Boolean).join("  •  ") });
  }, [cur.t, prefs.imgTheme, prefs.imgSize, prefs.font, prefs.sign]);
  useEffect(() => {
    const d = dlgRef.current; if (!d) return;
    if (dlg && !d.open) { typeof d.showModal === "function" ? d.showModal() : d.setAttribute("open", ""); }
    if (dlg) drawImage();
  }, [dlg, drawImage]);
  const blob = () => new Promise(r => canvasRef.current.toBlob(r, "image/png"));
  const download = async () => {
    const url = URL.createObjectURL(await blob()), a = document.createElement("a");
    a.href = url; a.download = `subah-bakhair-${Date.now()}.png`; document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000); flash("تصویر محفوظ ہو گئی ✓");
  };
  const shareImage = async () => {
    const file = new File([await blob()], "subah-bakhair.png", { type: "image/png" });
    if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file], text: cur.t.trim() }); } catch { /* cancelled */ } } else download();
  };

  // category / relation
  const selectCat = k => { const np = { ...prefs, cat: k }; setPrefs(np); setOcc(null); document.querySelector(`.chip[data-k="${k}"]`)?.scrollIntoView({ inline: "nearest", block: "nearest", behavior: REDUCED ? "auto" : "smooth" }); generate(np); };
  const pickRelation = v => { const r = RELATIONS[v] || {}; setP({ relation: v, ...(r.gender ? { gender: r.gender } : {}) }); };

  // keyboard shortcuts + scroll effects
  const keys = useRef(); keys.current = { generate, copy, toggleFav, dlg };
  useEffect(() => {
    const onKey = e => {
      if (e.target.closest("input, textarea, select") || e.metaKey || e.ctrlKey || e.altKey || keys.current.dlg) return;
      const k = e.key.toLowerCase();
      if (k === "n") { e.preventDefault(); keys.current.generate(); } else if (k === "c") { e.preventDefault(); keys.current.copy(); } else if (k === "f") { e.preventDefault(); keys.current.toggleFav(); }
    };
    let tick = false;
    const onScroll = () => { if (tick) return; tick = true; requestAnimationFrame(() => {
      const m = document.documentElement.scrollHeight - innerHeight;
      if (barRef.current) barRef.current.style.transform = `scaleX(${m > 0 ? scrollY / m : 0})`;
      document.documentElement.style.setProperty("--py", Math.min(scrollY, 600)); tick = false; }); };
    document.addEventListener("keydown", onKey); addEventListener("scroll", onScroll, { passive: true });
    return () => { document.removeEventListener("keydown", onKey); removeEventListener("scroll", onScroll); };
  }, []);

  const voc = window.CATEGORIES.vocative(prefs.relation, prefs.name, rel.gender || prefs.gender || "m");
  const summary = [voc || (prefs.relation ? rel.label : null), prefs.register || (byKey[prefs.cat] || {}).register || "آپ", { short: "مختصر", medium: "درمیانہ", long: "تفصیلی" }[prefs.length]].filter(Boolean).join(" · ");
  const items = tab === "hist" ? history.slice(1) : favs;
  const words = cur.t.split(/\s+/).filter(Boolean).length;
  const THEME_ICON = { auto: "auto", light: "sun", dark: "moon" };
  const marquee = [...PHRASES, ...PHRASES];

  return (
    <>
      <div className="progress" ref={barRef} aria-hidden="true" />
      <header className="top">
        <a className="brand" href="/"><img src="/icon.svg" alt="" width="30" height="30" /><span>صبح بخیر پیغامات</span></a>
        <nav className="topnav" aria-label="مینو"><a href="#generator">پیغام بنائیں</a><a href="#features">خصوصیات</a><a href="#faq">سوالات</a></nav>
        <Btn className="icon-btn" aria-label="تھیم بدلیں" title={"تھیم: " + { auto: "خودکار", light: "روشن", dark: "تاریک" }[prefs.theme]} onClick={() => setP({ theme: { auto: "light", light: "dark", dark: "auto" }[prefs.theme] })}><Icon n={THEME_ICON[prefs.theme]} /></Btn>
      </header>

      <section className="hero" aria-labelledby="heroTitle">
        <HeroSlider />
        <div className="hero-in">
          <div className="hero-text">
            <p className="greet"><span className="pulse-dot" aria-hidden="true" />{Urdu.timeGreeting(now)}</p>
            <h1 id="heroTitle"><Flow text="اردو صبح بخیر پیغام، ہر بار نیا اور دل کے قریب" cls="hw" /></h1>
            <p className="lede">آج کس کا دن روشن کرنا ہے؟ ایک ٹیپ میں پیغام بنائیں، واٹس ایپ پر بھیجیں یا اسٹیٹس کی خوبصورت تصویر بنائیں۔</p>
            <Thought />
            <div className="hero-cta">
              <a className="cta" href="#generator">ابھی پیغام بنائیں<Icon n="sparkle" /></a>
              <a className="cta ghost" href="#features">خصوصیات دیکھیں</a>
            </div>
            <p className="date"><span>{dl.gregorian}</span><span className="dot" aria-hidden="true">•</span><span>{dl.hijri}</span></p>
            <ul className="stats" aria-label="خلاصہ">
              <li><b>{Urdu.toUrduDigits(12)}</b><span>اقسام</span></li>
              <li><b>{Urdu.toUrduDigits(5)}</b><span>تصویری ڈیزائن</span></li>
              <li><b>مفت</b><span>ہمیشہ</span></li>
            </ul>
          </div>
        </div>
      </section>

      <div className="marquee" aria-hidden="true"><div className="track">{marquee.map((p, i) => <span key={i}>{p}</span>)}</div></div>

      <main>
        <section id="generator" aria-labelledby="gT">
          {occ && <button className="occasion" onClick={() => selectCat(occ.key)}>{occ.label}</button>}
          <h2 className="section-title" id="gT">کس کے لیے لکھنا ہے؟</h2>
          <nav className="cats" aria-label="پیغام کی قسم">
            {CATS.map((c, i) => (
              <button key={c.key} className="chip" data-k={c.key} title={c.desc} style={{ "--n": i }} aria-pressed={c.key === prefs.cat} onClick={() => selectCat(c.key)}>
                <span className="ico" aria-hidden="true">{c.icon}</span>{c.key}
              </button>
            ))}
          </nav>

          <details className="panel">
            <summary><Icon n="sliders" /><span>ذاتی رنگ دیں</span><small>{summary}</small></summary>
            <div className="grid">
              <label className="field"><span>نام</span><input value={prefs.name} disabled={!!rel.fixed} maxLength={40} autoComplete="off" onChange={e => setP({ name: e.target.value })} placeholder={rel.fixed ? `«${rel.alone}» کہہ کر مخاطب کیا جائے گا` : "مثلاً علی، سارہ (اختیاری)"} /></label>
              <label className="field"><span>رشتہ</span><select value={prefs.relation} onChange={e => pickRelation(e.target.value)}>{Object.entries(RELATIONS).map(([k, r]) => <option key={k} value={k}>{r.label}</option>)}</select></label>
              <div className="field"><span>جنس</span><Seg name="جنس" locked={!!rel.gender} value={rel.gender || prefs.gender} opts={[["", "نامعلوم"], ["m", "مرد"], ["f", "خاتون"]]} onPick={v => setP({ gender: v })} /></div>
              <div className="field"><span>طرزِ خطاب</span><Seg name="طرزِ خطاب" value={prefs.register} opts={[["", "خودکار"], ["آپ", "آپ"], ["تم", "تم"]]} onPick={v => setP({ register: v })} /></div>
              <div className="field"><span>لمبائی</span><Seg name="لمبائی" value={prefs.length} opts={[["short", "مختصر"], ["medium", "درمیانہ"], ["long", "تفصیلی"]]} onPick={v => setP({ length: v })} /></div>
              <label className="field switch"><span>ایموجی</span><input type="checkbox" role="switch" checked={prefs.emoji} onChange={e => setP({ emoji: e.target.checked })} /><i aria-hidden="true" /></label>
            </div>
          </details>

          <article className={"card" + (partial ? " streaming" : "")} ref={cardRef} aria-busy={!!busy}>
            <div className="card-bar">
              {cur.src && <span className={"badge" + (!navigator.onLine ? " off" : "")}>{cur.src === "ai" ? "✨ AI سے تازہ" : cur.src === "offline" ? "آف لائن نمونہ" : "آپ کی ترمیم"}</span>}
              <div className="card-tools">
                <select value={prefs.font} aria-label="فونٹ" onChange={e => setP({ font: e.target.value })}><option value="nastaliq">نستعلیق</option><option value="gulzar">گلزار</option><option value="naskh">نسخ</option></select>
                <Btn className="icon-btn sm" aria-label="چھوٹا متن" onClick={() => setP({ size: Math.max(1, +(prefs.size - .1).toFixed(2)) })}>ا<sub>-</sub></Btn>
                <Btn className="icon-btn sm" aria-label="بڑا متن" onClick={() => setP({ size: Math.min(2.2, +(prefs.size + .1).toFixed(2)) })}>ا<sup>+</sup></Btn>
                <Btn className="icon-btn sm" aria-label="ترمیم کریں" aria-pressed={editing} onClick={toggleEdit}><Icon n="edit" /></Btn>
              </div>
            </div>
            {err && !busy && <div className="err" role="alert"><p>{ERR[err.kind] || ERR.failed}</p><Btn className="link" onClick={() => generate()}>{err.kind === "rate_limit" && err.n > 0 ? `دوبارہ کوشش (${Urdu.toUrduDigits(err.n)})` : "دوبارہ کوشش کریں"}</Btn></div>}
            {editing
              ? <textarea className="msg-edit" autoFocus value={draft} aria-label="پیغام میں ترمیم" onChange={e => setDraft(e.target.value)} onKeyDown={e => e.key === "Escape" && setEditing(false)} />
              : partial ? <div className="msg" aria-live="off"><Message text={partial} animate={false} /></div>
              : cur.t && !err && <div className="msg" key={cur.id} aria-live="polite"><Message text={cur.t} animate={cur.animate} /></div>}
            <div className="skeleton" aria-hidden="true"><i /><i /><i /></div>
            <div className="card-foot"><span>{cur.t && !err ? `${Urdu.toUrduDigits(words)} الفاظ` : ""}</span>
              {undo && <Btn className="link" onClick={() => { setMessage(undo.t, undo.src || "edited", { animate: false }); setUndo(null); }}><Icon n="undo" />پچھلا متن واپس لائیں</Btn>}</div>
          </article>

          <div className={"refine" + (!navigator.onLine ? " off" : "")} role="group" aria-label="پیغام کو بہتر بنائیں">
            <span className="refine-label"><Icon n="sparkle" />بہتر بنائیں:</span>
            {[["shorter", "مختصر کریں"], ["warmer", "مزید پیار بھرا"], ["formal", "زیادہ مؤدبانہ"], ["poetry", "شعر شامل کریں"], ["dua", "دعا شامل کریں"], ["fix", "اصلاح کریں"]].map(([a, l]) => <Btn key={a} disabled={!!busy} onClick={() => refine(a)}>{l}</Btn>)}
          </div>

          <div className="actions">
            <Btn className="primary" magnetic disabled={!!busy} onClick={() => generate()}><Icon n="sparkle" /><span>{busy || "نیا پیغام"}</span><kbd>N</kbd></Btn>
            <div className="secondary">
              <Btn onClick={copy} title="کاپی (C)"><Icon n="copy" /><span>کاپی</span></Btn>
              <Btn className="wa" onClick={whatsapp}><Icon n="wa" /><span>واٹس ایپ</span></Btn>
              <Btn onClick={() => { if (commit()) setDlg(true); }}><Icon n="image" /><span>تصویر</span></Btn>
              <Btn onClick={share}><Icon n="share" /><span>شیئر</span></Btn>
              <Btn id="fav" aria-pressed={!!isFav} onClick={toggleFav}><Icon n="heart" /><span>{isFav ? "محفوظ" : "پسندیدہ"}</span>
                {burst > 0 && isFav && <span className="burst" key={burst} aria-hidden="true">{[0, 1, 2, 3, 4, 5].map(i => <i key={i} style={{ "--a": i * 60 + "deg" }}>❤</i>)}</span>}</Btn>
              <Btn id="speak" aria-pressed={speaking} onClick={speak}><Icon n="sound" /><span>سنیں</span></Btn>
            </div>
          </div>
        </section>

        <Rv as="section" className="sec" aria-labelledby="galT">
          <div className="sec-head"><h2 id="galT">صبح کے خوبصورت مناظر</h2></div>
          <div className="gallery">
            {[["/img/chai.svg", "چائے کی پہلی چسکی", "سکون بھری صبح کا آغاز"], ["/img/garden.svg", "باغ میں کھلتی صبح", "تازگی اور مسکراہٹ"], ["/img/dua.svg", "فجر کے بعد کی دعا", "دل کا اطمینان"]].map(([src, t, d], i) => (
              <Rv as="figure" className="shot" k={i} key={src}><div className="shot-img"><img src={src} alt={t} loading="lazy" width="480" height="360" /></div><figcaption><b>{t}</b><span>{d}</span></figcaption></Rv>
            ))}
          </div>
        </Rv>

        <Rv as="section" className="sec" id="features" aria-labelledby="fT">
          <div className="sec-head"><h2 id="fT">یہ پیغام ساز کیوں خاص ہے</h2></div>
          <div className="feats">{FEATURES.map(([e, t, d], i) => <Rv as="article" className="feat" k={i} key={t}><span className="fi" aria-hidden="true">{e}</span><h3>{t}</h3><p>{d}</p></Rv>)}</div>
        </Rv>

        <Rv as="section" className="sec" aria-labelledby="dT">
          <div className="sec-head"><h2 id="dT">صبح کی مسنون دعا</h2></div>
          <Rv className="dua">
            <div className="ar2" dir="rtl" lang="ar"><Flow text={DUA} cls="w" /></div>
            <p className="ur2">اے اللہ! تیری ہی توفیق سے ہم نے صبح کی اور شام کی، تیرے ہی حکم سے جیتے اور مرتے ہیں، اور تیری ہی طرف لوٹنا ہے۔</p>
            <span className="rf">سنن ترمذی، ۳۳۹۱</span>
          </Rv>
        </Rv>

        <Rv as="section" className="sec" aria-labelledby="wT">
          <div className="sec-head"><h2 id="wT">صبح کے خوبصورت الفاظ</h2></div>
          <div className="words">{WORDS.map(([w, m], i) => <Rv className="wd" k={i} key={w}><b>{w}</b><p>{m}</p></Rv>)}</div>
        </Rv>

        <Rv as="section" className="how" aria-labelledby="howT">
          <h2 className="section-title" id="howT">تین قدم، اور پیغام تیار</h2>
          <ol className="steps">
            <li><b>۱</b><h3>قسم چنیں</h3><p>اسلامی، دوستوں، گھر والوں یا دفتر، جس کے لیے لکھنا ہو۔</p></li>
            <li><b>۲</b><h3>رنگ بھریں</h3><p>نام اور رشتہ لکھیں تو پیغام آپ کے انداز میں ڈھل جاتا ہے۔</p></li>
            <li><b>۳</b><h3>بھیج دیں</h3><p>کاپی کریں، واٹس ایپ کھولیں یا اسٹیٹس کے لیے تصویر بنائیں۔</p></li>
          </ol>
        </Rv>

        <section className="lists" aria-label="آپ کے پیغامات">
          <div className="tabs" role="tablist">
            <button role="tab" aria-selected={tab === "hist"} onClick={() => setTab("hist")}>پچھلے پیغامات</button>
            <button role="tab" aria-selected={tab === "fav"} onClick={() => setTab("fav")}>پسندیدہ <b>{favs.length ? Urdu.toUrduDigits(favs.length) : ""}</b></button>
          </div>
          <div role="tabpanel">
            {!items.length && <p className="empty">{tab === "hist" ? "ابھی کوئی پچھلا پیغام نہیں۔" : "دل کے نشان سے پیغامات یہاں محفوظ کریں۔"}</p>}
            {items.map(it => (
              <div className="item" key={it.d + it.t.slice(0, 8)}>
                <button className="text" onClick={() => { setEditing(false); setCur(c => ({ t: it.t, c: it.c, src: "", id: c.id + 1, animate: false })); scrollTo({ top: cardRef.current.offsetTop - 80, behavior: REDUCED ? "auto" : "smooth" }); }}>{it.t.replace(/\n+/g, " · ")}</button>
                <span className="tag">{(byKey[it.c] || {}).icon || ""} {timeAgo(it.d)}</span>
                <Btn className="icon-btn" aria-label="حذف کریں" onClick={() => tab === "hist" ? setHistory(h => h.filter(x => x !== it)) : setFavs(f => f.filter(x => x !== it))}><Icon n="trash" /></Btn>
              </div>
            ))}
          </div>
        </section>

        <Rv as="section" className="sec" id="faq" aria-labelledby="qT">
          <div className="sec-head"><h2 id="qT">اکثر پوچھے گئے سوالات</h2></div>
          <div className="faq">{FAQ.map(([q, a]) => <details key={q}><summary>{q}</summary><p>{a}</p></details>)}</div>
        </Rv>

        <footer className="foot">
          <strong>صبح بخیر، اور شکریہ</strong>
          <p>قرآنی آیات اور ادعیہ حوالے کے ساتھ دی گئی ہیں۔ AI سے بنے پیغامات بھیجنے سے پہلے ایک نظر ضرور دیکھ لیں۔</p>
          <p className="kw">اردو صبح بخیر پیغامات · اسلامی گڈ مارننگ · جمعہ مبارک پیغام · واٹس ایپ اسٹیٹس</p>
        </footer>
      </main>

      <dialog ref={dlgRef} aria-labelledby="imgTitle" onClose={() => setDlg(false)} onClick={e => e.target === dlgRef.current && dlgRef.current.close()}>
        <form method="dialog" className="dlg">
          <header><h2 id="imgTitle">اسٹیٹس کے لیے تصویر</h2><button className="icon-btn" value="close" aria-label="بند کریں"><Icon n="close" /></button></header>
          <div className="preview"><canvas ref={canvasRef} width="1080" height="1080" /></div>
          <div className="dlg-opts">
            <div className="swatches" role="radiogroup" aria-label="ڈیزائن">
              {Object.entries(Card.THEMES).map(([k, t]) => <button key={k} type="button" role="radio" title={t.name} aria-label={t.name} aria-checked={k === prefs.imgTheme} style={{ background: t.swatch }} onClick={() => setP({ imgTheme: k })} />)}
            </div>
            <Seg name="سائز" type="button" value={prefs.imgSize} opts={[["square", "مربع ۱:۱"], ["story", "اسٹیٹس ۹:۱۶"]]} onPick={v => setP({ imgSize: v })} />
            <label className="field"><span>دستخط (اختیاری)</span><input value={prefs.sign} maxLength={30} placeholder="مثلاً: منجانب احمد" onChange={e => setP({ sign: e.target.value })} /></label>
          </div>
          <footer>
            <Btn type="button" className="primary" onClick={download}><Icon n="download" />ڈاؤن لوڈ</Btn>
            <Btn type="button" onClick={shareImage}><Icon n="share" />شیئر کریں</Btn>
          </footer>
        </form>
      </dialog>

      <div id="toast" className={toast.on ? "on" : ""} role="status" aria-live="polite"><span>{toast.m}</span></div>
    </>
  );
}
