// Builds the Chrome extension from the web app so the two never drift apart.
// Usage: npm run build:ext   (then load the "extension" folder in chrome://extensions)
const fs = require("fs"), path = require("path");
const root = path.join(__dirname, ".."), pub = path.join(root, "public"), ext = path.join(root, "extension");

const copy = (rel) => {
  const src = path.join(pub, rel), dst = path.join(ext, rel);
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.cpSync(src, dst, { recursive: true });
};
["styles.css", "fonts.css", "fonts", "js", "icon.svg"].forEach(copy);
fs.rmSync(path.join(ext, "js", "app.js.map"), { force: true });

let html = fs.readFileSync(path.join(pub, "index.html"), "utf8")
  .replace(/<link rel="manifest"[^>]*>\n/, "")
  .replace(/<link rel="apple-touch-icon"[^>]*>\n/, "")
  .replace(/<meta name="theme-color"[^>]*>\n/g, "")
  .replace('<link rel="stylesheet" href="styles.css">', '<link rel="stylesheet" href="styles.css">\n<link rel="stylesheet" href="popup.css">')
  .replace('<script src="js/urdu.js"></script>', '<script src="config.js"></script>\n<script src="js/urdu.js"></script>');
fs.writeFileSync(path.join(ext, "popup.html"), html);

const pkg = require(path.join(root, "package.json"));
const manifest = JSON.parse(fs.readFileSync(path.join(ext, "manifest.json"), "utf8"));
manifest.version = pkg.version;
fs.writeFileSync(path.join(ext, "manifest.json"), JSON.stringify(manifest, null, 2) + "\n");
console.log(`extension built (v${pkg.version}) → ${path.relative(process.cwd(), ext)}`);
