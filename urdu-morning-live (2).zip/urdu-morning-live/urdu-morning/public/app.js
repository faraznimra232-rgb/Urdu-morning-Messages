
// Each category = pools; message = one item from each pool, so combinations multiply.
const DATA = {
  "اسلامی": {
    open: ["السلام علیکم ورحمۃ اللہ وبرکاتہ","السلام علیکم! صبح بخیر","اللہ کے نام سے دن کا آغاز مبارک","فجر کی روشنی مبارک، السلام علیکم","الحمدُ للہ! ایک اور خوبصورت صبح"],
    body: ["اللہ تعالیٰ آج کے دن کو آپ کے لیے آسانیوں اور برکتوں والا بنائے۔","ہر صبح اللہ کی رحمت کا نیا پیغام ہے، اس کا شکر ادا کریں۔","جو اللہ پر بھروسا کرتا ہے، اللہ اس کے لیے کافی ہو جاتا ہے۔","آج کوئی نیکی ضرور کریں، چاہے مسکراہٹ ہی کیوں نہ ہو۔","مشکل کے ساتھ آسانی ہے، یہ اللہ کا وعدہ ہے۔","رزق حلال اور نیک نیت کے ساتھ دن شروع کریں، اللہ برکت دے گا۔","آج کسی کے لیے دعا کریں، فرشتے آپ کے لیے وہی دعا کرتے ہیں۔"],
    close: ["اللہ آپ کو اور آپ کے گھر والوں کو سلامت رکھے۔ آمین","دعاؤں میں یاد رکھیے گا۔","اللہ حافظ، دن مبارک ہو۔","اللہ آپ کے دل کو سکون اور رزق میں برکت دے۔ آمین","آپ کا دن نور سے بھرا رہے۔"],
    extra: ["فَإِنَّ مَعَ الْعُسْرِ يُسْرًا","رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي","حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ","اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا","سُبْحَانَ اللهِ وَبِحَمْدِهِ"]
  },
  "عمومی": {
    open: ["صبح بخیر!","سلام! صبح بخیر","نیا دن، نئی صبح، صبح بخیر","صبح بخیر! امید ہے نیند اچھی رہی","خوشگوار صبح مبارک ہو"],
    body: ["آج کا دن آپ کے لیے اچھی خبریں لے کر آئے۔","ایک گہری سانس لیں، چائے کا کپ پکڑیں اور دن کا آغاز مسکراہٹ سے کریں۔","جو گزر گیا اسے چھوڑ دیں، آج نیا موقع ہے۔","چھوٹے چھوٹے قدم ہی بڑی منزل تک پہنچاتے ہیں۔","سورج پھر نکلا ہے، آپ کے لیے بھی نئی امید کے ساتھ۔","آج خود سے وعدہ کریں کہ ایک کام دل لگا کر کریں گے۔"],
    close: ["دن بہت اچھا گزرے!","ہنستے مسکراتے رہیں۔","اپنا خیال رکھیے گا۔","خوش رہیں، آباد رہیں۔","آپ کا دن شاندار ہو!"],
    extra: ["☀️","🌿","☕","🌼","✨"]
  },
  "حوصلہ افزائی": {
    open: ["اٹھیے، نیا دن آپ کا منتظر ہے!","صبح بخیر، ہمت والو!","صبح بخیر! آج کچھ کر دکھانے کا دن ہے","جاگیے، خواب سچ کرنے کا وقت ہے"],
    body: ["کامیابی ان کے قدم چومتی ہے جو مشکل میں بھی چلتے رہتے ہیں۔","آج کا دن کل کے پچھتاوے سے بہتر بنانے کا موقع ہے۔","ہار ماننے والا کبھی نہیں جیتتا، اور جیتنے والا کبھی ہار نہیں مانتا۔","خود پر یقین رکھیں، آپ جتنا سمجھتے ہیں اس سے زیادہ کر سکتے ہیں۔","محنت کا پھل دیر سے سہی، مگر میٹھا ضرور ملتا ہے۔","ڈر کو پیچھے چھوڑیں، پہلا قدم اٹھائیں، راستہ خود بنتا جائے گا۔"],
    close: ["چلیں، آج کا دن اپنے نام کریں!","آپ کر سکتے ہیں، بس شروع کیجیے۔","کامیاب دن کی دعا کے ساتھ۔","آج کچھ ایسا کریں کہ کل خود پر فخر ہو۔"],
    extra: ["💪","🚀","🔥","🌅"]
  },
  "دوستوں کے لیے": {
    open: ["اوئے صبح بخیر!","سلام یار! صبح بخیر","میرے پیارے دوست، صبح بخیر","اٹھ جاؤ سونے والو! صبح بخیر"],
    body: ["دوست وہ ہوتے ہیں جن کی یاد ہر صبح بغیر وجہ آ جاتی ہے۔","تمہاری دوستی میری زندگی کی سب سے اچھی کمائی ہے۔","آج کا ناشتہ اچھا کرنا، اور مجھے یاد بھی کرنا۔","جب تک تم جیسے دوست ہیں، ہر صبح خوبصورت ہے۔","سوچا دن کی شروعات تمہیں یاد کر کے کر لوں۔"],
    close: ["ملتے ہیں جلد!","بس ایسے ہی مسکراتے رہنا۔","دن اچھا گزرے میرے یار!","اللہ تمہیں ہمیشہ خوش رکھے۔"],
    extra: ["🤝","😄","🌞","☕"]
  },
  "گھر والوں کے لیے": {
    open: ["السلام علیکم! صبح بخیر","صبح بخیر، میرے اپنو","سلام امی ابو اور سب گھر والوں کو","صبح بخیر پیارے گھر والو"],
    body: ["آپ سب کے دم سے ہی میرا ہر دن روشن ہے۔","گھر کی دعائیں ساتھ ہوں تو ہر مشکل آسان لگتی ہے۔","اللہ ہمارے گھر کو ہمیشہ محبت اور سکون سے بھرا رکھے۔","آج کا دن آپ سب کے لیے صحت اور خوشیاں لائے۔"],
    close: ["اپنا خیال رکھیے گا۔","شام کو ملتے ہیں، ان شاء اللہ۔","دعاؤں میں یاد رکھیے گا۔","آپ سب سے بہت محبت ہے۔"],
    extra: ["🏡","🤲","❤️","🌸"]
  }
};

const $ = id => document.getElementById(id);
let cat = "اسلامی", last = {}, history = [];
const pick = (arr, key) => { // avoids repeating the previous choice
  let i; do { i = Math.floor(Math.random()*arr.length); } while (arr.length>1 && i===last[key]);
  last[key]=i; return arr[i];
};
function build(){
  const d = DATA[cat], n = $("name").value.trim();
  const isIslamic = cat==="اسلامی";
  let o = pick(d.open, cat+"o");
  if(n) o = o + "، " + n;
  const parts = [o+"،", pick(d.body,cat+"b")];
  const ex = pick(d.extra, cat+"e");
  if(isIslamic) parts.push("\n"+ex);
  parts.push("\n"+pick(d.close,cat+"c") + (isIslamic?"":" "+ex));
  return parts.join("\n").replace("،،","،");
}
async function show(){
  const btn=$("gen"); btn.disabled=true; btn.textContent="...";
  let m;
  try{
    const r=await fetch((window.API_BASE||"")+"/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({category:cat,name:$("name").value.trim(),avoid:history.slice(0,3)})});
    if(!r.ok) throw new Error("api"); m=(await r.json()).message;
  }catch(e){ m=build(); } // offline / server down: use built-in templates
  btn.disabled=false; btn.textContent="نیا پیغام";
  $("msg").textContent=m;
  history.unshift(m); history=history.slice(0,8);
  $("hist").innerHTML=""; history.slice(1).forEach(h=>{
    const el=document.createElement("div"); el.textContent=h.replace(/\n+/g," "); el.onclick=()=>{$("msg").textContent=h};
    $("hist").appendChild(el);
  });
}
function toast(t){ const e=$("toast"); e.firstChild.textContent=t; e.classList.add("on"); setTimeout(()=>e.classList.remove("on"),1500); }
Object.keys(DATA).forEach(k=>{
  const b=document.createElement("button"); b.textContent=k; b.setAttribute("aria-pressed", k===cat);
  b.onclick=()=>{cat=k; document.querySelectorAll("#cats button").forEach(x=>x.setAttribute("aria-pressed", x===b)); show();};
  $("cats").appendChild(b);
});
$("gen").onclick=show;
$("copy").onclick=async()=>{ try{ await navigator.clipboard.writeText($("msg").textContent); toast("کاپی ہو گیا"); }catch(e){ toast("کاپی نہیں ہو سکا"); } };
$("wa").onclick=()=>window.open("https://wa.me/?text="+encodeURIComponent($("msg").textContent),"_blank");
show();
