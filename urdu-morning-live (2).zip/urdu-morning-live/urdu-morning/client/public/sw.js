/* Service worker.
   - Pages (HTML): network first, so a new build shows up immediately; the cached copy is only used offline.
   - Our other files: stale-while-revalidate. The API is never cached.
   - When this version replaces an older one (e.g. the classic UI's worker), old caches are deleted and open tabs reload once. */
const SHELL = "shell-react-v6";
const FILES = ["/", "/fonts.css", "/fonts/noto-nastaliq-urdu-400-normal.woff2", "/fonts/noto-naskh-arabic-400-normal.woff2",
  "/manifest.json", "/icon.svg", "/icon-192.png", "/js/urdu.js", "/js/categories.js", "/js/card.js", "/img/chai.svg", "/img/garden.svg", "/img/dua.svg"];

self.addEventListener("install", e => e.waitUntil(
  // one missing file must never stop the update, so each file is cached on its own
  caches.open(SHELL).then(c => Promise.allSettled(FILES.map(f => c.add(f)))).then(() => self.skipWaiting())));

self.addEventListener("activate", e => e.waitUntil((async () => {
  const old = (await caches.keys()).filter(k => k !== SHELL);
  await Promise.all(old.map(k => caches.delete(k)));
  await self.clients.claim();
  if (old.length) for (const c of await self.clients.matchAll({ type: "window" })) Promise.resolve(c.navigate(c.url)).catch(() => {});
})()));

self.addEventListener("fetch", e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== location.origin || url.pathname.startsWith("/api/")) return;
  if (req.mode === "navigate") {
    e.respondWith(fetch(req).then(r => { if (r.ok) { const copy = r.clone(); caches.open(SHELL).then(c => c.put("/", copy)); } return r; })
      .catch(() => caches.match("/")));
    return;
  }
  e.respondWith(caches.open(SHELL).then(async c => {
    const hit = await c.match(req, { ignoreSearch: true });
    const net = fetch(req).then(r => { if (r.ok) c.put(req, r.clone()); return r; }).catch(() => hit || c.match("/"));
    return hit || net;
  }));
});
