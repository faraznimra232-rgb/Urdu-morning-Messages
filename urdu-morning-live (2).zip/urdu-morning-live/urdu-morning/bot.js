// Daily auto-send to Telegram. Run: npm run bot   (test now: node bot.js --now)
// Smart defaults: Friday → جمعہ مبارک, Ramadan → رمضان المبارک, Eid days → عید مبارک.
require("dotenv").config();
const cron = require("node-cron");
const { generate, CATS } = require("./lib/generate");
const Urdu = require("./public/js/urdu.js");

const token = process.env.TELEGRAM_BOT_TOKEN;
const chats = (process.env.TELEGRAM_CHAT_IDS || "").split(",").map(s => s.trim()).filter(Boolean);
const TIME = process.env.SEND_TIME || "07:00";
const TZ = process.env.TZ || "Asia/Karachi";
// SEND_CATEGORY can be one category or several separated by | to rotate daily, e.g. اسلامی|عمومی|حوصلہ افزائی
const rotation = (process.env.SEND_CATEGORY || "اسلامی").split("|").map(s => s.trim()).filter(k => CATS.some(c => c.key === k));
const smart = process.env.SMART_OCCASIONS !== "false";

if (!token || !chats.length) { console.error("Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_IDS in .env"); process.exit(1); }
if (!/^\d{1,2}:\d{2}$/.test(TIME)) { console.error("SEND_TIME must be HH:MM"); process.exit(1); }
if (!rotation.length) rotation.push("اسلامی");
const [hh, mm] = TIME.split(":").map(Number);

const recent = [];
let day = 0;

function categoryForToday() {
  const occ = smart && Urdu.occasion(new Date());
  if (occ && CATS.some(c => c.key === occ.key)) return occ.key;
  return rotation[day++ % rotation.length];
}

async function sendTo(chat_id, text, tries = 3) {
  for (let i = 1; i <= tries; i++) {
    try {
      const r = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id, text })
      });
      if (r.ok) return true;
      const body = await r.text();
      if (r.status < 500 && r.status !== 429) { console.error("Telegram error", chat_id, body); return false; }
    } catch (e) { console.error("network", chat_id, e.message); }
    await new Promise(res => setTimeout(res, 2000 * i));
  }
  return false;
}

async function send() {
  const category = categoryForToday();
  // AI only — retry for ~15 minutes (rate limits, outages) rather than send a canned message
  let message, model;
  for (const waitMin of [0, 1, 3, 10]) {
    if (waitMin) { console.log(`retrying in ${waitMin} min…`); await new Promise(r => setTimeout(r, waitMin * 60_000)); }
    try { ({ message, model } = await generate({ category, avoid: recent.slice(-3), length: "medium" })); break; }
    catch (e) { console.error("generate failed:", e.message); }
  }
  if (!message) return console.error(new Date().toISOString(), "skipped today — AI unavailable");
  const source = model;
  recent.push(message); if (recent.length > 10) recent.shift();
  const results = await Promise.all(chats.map(c => sendTo(c, message)));
  console.log(new Date().toISOString(), `[${category} · ${source}]`, `${results.filter(Boolean).length}/${chats.length} sent`);
}

cron.schedule(`${mm} ${hh} * * *`, () => send().catch(e => console.error("send failed:", e.message)), { timezone: TZ });
console.log(`Scheduled daily at ${TIME} ${TZ} · rotation: ${rotation.join(" → ")}${smart ? " · smart occasions on" : ""}`);
if (process.argv.includes("--now")) send();
