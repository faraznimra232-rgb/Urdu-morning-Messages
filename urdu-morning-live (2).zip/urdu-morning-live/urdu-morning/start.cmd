@echo off
rem Double-click to run: installs packages if needed, rebuilds the web app, starts the server.
cd /d "%~dp0"
if not exist node_modules (
  echo Installing packages ^(first time only^)...
  call npm install
)
echo Building the web app...
call npm run build
echo.
echo Starting the server - open http://localhost:3000   ^(Ctrl+C to stop^)
call npm start
pause
