/* Service worker: app shell precache + stale-while-revalidate for our own files (incl. fonts). API is never cached. */
const VERSION = "v2.1.0";
const SHELL = `shell-${VERSION}`;
const FILES = ["./", "index.html", "styles.css", "fonts.css", "fonts/noto-nastaliq-urdu-400-normal.woff2", "fonts/noto-naskh-arabic-400-normal.woff2", "manifest.json", "icon.svg", "icon-192.png", "icon-512.png",
  "js/urdu.js", "js/categories.js", "js/card.js", "js/app.js"];

self.addEventListener("install", e => e.waitUntil(caches.open(SHELL).then(c => c.addAll(FILES)).then(() => self.skipWaiting())));
self.addEventListener("activate", e => e.waitUntil(
  caches.keys().then(keys => Promise.all(keys.filter(k => k !== SHELL).map(k => caches.delete(k)))).then(() => self.clients.claim())
));

self.addEventListener("fetch", e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET" || url.pathname.startsWith("/api/")) return;

  if (url.origin !== location.origin) return;

  e.respondWith(caches.open(SHELL).then(async c => {
    const hit = await c.match(req, { ignoreSearch: true });
    const net = fetch(req).then(res => { if (res.ok) c.put(req, res.clone()); return res; }).catch(() => hit || c.match("index.html"));
    return hit || net;
  }));
});
