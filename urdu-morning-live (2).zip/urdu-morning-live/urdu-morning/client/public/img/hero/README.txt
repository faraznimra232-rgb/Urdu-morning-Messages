Apni ek real photo yahan rakhein aur naam rakhein:  book.jpg
Landscape, 1920x1080 ya bari, 400KB se kam.
Phir start.cmd dobara chalayein (ya: npm run build) aur Ctrl+Shift+R karein.
Slides ki list client/src/content.js me SLIDES hai.
